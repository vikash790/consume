import Hero from "./Hero";
import Services from "./Services";
import Products from "./Products";

export default function Home() {
  return (
    <>
      <Hero />
      <Services />
      <Products />
    </>
  );
}
