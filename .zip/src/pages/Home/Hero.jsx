// // import heroImage from "../../assets/hero.jpg";

// // import Container from "../../components/Container";

// // export default function Hero() {
// //   return (
// //     <section className="hero">
// //       <img src={heroImage} className="hero-img" />

// //       <div className="overlay"></div>

// //       <Container>
// //         <div className="hero-content">
// //           <h3 className="tag">NEW SPECIAL OFFERS</h3>
// //           <h1>Financial Products That Fit Your Lifestyle</h1>
// //           <p>Explore exclusive offers available this month.</p>

// //           <button className="btn-primary big">See More</button>
// //         </div>
// //       </Container>
// //     </section>
// //   );
// // }


// import { useEffect, useState } from "react";
// import Container from "../../components/Container";

// import hero1 from "../../assets/hero.jpg";
// import hero2 from "../../assets/hero1.jpg";
// import hero3 from "../../assets/hero2.jpg";

// const images = [hero1, hero2, hero3];

// export default function Hero() {
//   const [index, setIndex] = useState(0);

//   useEffect(() => {
//     const timer = setInterval(() => {
//       setIndex((prev) => (prev + 1) % images.length);
//     }, 4000); // change every 4 seconds

//     return () => clearInterval(timer);
//   }, []);

//   return (
//     <section className="hero">
//       {images.map((img, i) => (
//         <img
//           key={i}
//           src={img}
//           className={`hero-img ${i === index ? "active" : ""}`}
//         />
//       ))}

//       <div className="overlay"></div>

//       <Container>
//         <div className="hero-content">
//           <h3 className="tag">NEW SPECIAL OFFERS</h3>
//           <h1>Financial Products That Fit Your Lifestyle</h1>
//           <p>Explore exclusive offers available this month.</p>
//           <button className="btn-primary big">See More</button>
//         </div>
//       </Container>
//     </section>
//   );
// }


import hero1 from "../../assets/hero.jpg";
import hero2 from "../../assets/hero1.jpg";
import hero3 from "../../assets/hero2.jpg";
import { useState, useEffect } from "react";

export default function Hero() {
  const images = [hero1, hero2, hero3];
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setIndex((prev) => (prev + 1) % images.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="hero">
      <img src={images[0]} className={`hero-img ${index === 0 ? "active" : ""}`} />
      <img src={images[1]} className={`hero-img ${index === 1 ? "active" : ""}`} />
      <img src={images[2]} className={`hero-img ${index === 2 ? "active" : ""}`} />

      <div className="overlay"></div>

      <div className="hero-content">
        <p className="tag">Digital Banking</p>
        <h1>Smart, Secure & Fast Banking Solutions</h1>
        <p>Experience seamless online banking with low fees and powerful tools.</p>

        <button className="btn-primary big">Get Started</button>
      </div>
    </section>
  );
}
