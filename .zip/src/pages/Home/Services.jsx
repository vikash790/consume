// import Container from "../../components/Container";

// export default function Services() {
//   return (
//     <section className="services">
//       <Container>
//         <div className="services-grid">
//           <div className="service-card">
//             <h4>Fund Transfer</h4>
//             <p>IMPS / NEFT / RTGS</p>
//           </div>

//           <div className="service-card">
//             <h4>Mobile Banking</h4>
//             <p>Anytime, anywhere</p>
//           </div>

//           <div className="service-card">
//             <h4>Credit Cards</h4>
//             <p>Instant approval</p>
//           </div>

//           <div className="service-card">
//             <h4>Branch Locator</h4>
//             <p>Find nearest branch</p>
//           </div>
//         </div>
//       </Container>
//     </section>
//   );
// }



export default function Services() {
  return (
    <section className="services">
      <div className="container">
        <div className="services-grid">

          <div className="service-card">
            <h4>Secure Banking</h4>
            <p>Your money is protected with top-level security.</p>
          </div>

          <div className="service-card">
            <h4>Instant Transfers</h4>
            <p>Send & receive money in seconds without extra fees.</p>
          </div>

          <div className="service-card">
            <h4>24/7 Support</h4>
            <p>We're here anytime you need help.</p>
          </div>

          <div className="service-card">
            <h4>Smart Insights</h4>
            <p>Track your spending with intelligent analytics.</p>
          </div>

        </div>
      </div>
    </section>
  );
}
