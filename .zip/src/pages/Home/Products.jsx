// import Container from "../../components/Container";

// export default function Products() {
//   return (
//     <section className="products">
//       <Container>
//         <h2>Our Products</h2>

//         <div className="products-grid" id="products">
//           <div className="product-card">
//             <h3>Savings Account</h3>
//             <p>High interest, zero hassle.</p>
//           </div>

//           <div className="product-card">
//             <h3>Fixed Deposit</h3>
//             <p>Guaranteed returns.</p>
//           </div>

//           <div className="product-card">
//             <h3>Personal Loans</h3>
//             <p>Fast approvals.</p>
//           </div>
//         </div>

//       </Container>
//     </section>
//   );
// }


export default function Products() {
  return (
    <section className="products" id="products">
      <div className="container">
        
        <h2>Our Products</h2>

        <div className="products-grid">
          
          <div className="product-card">
            <h3>Savings Account</h3>
            <p>Grow your savings with high interest rates.</p>
          </div>

          <div className="product-card">
            <h3>Credit Cards</h3>
            <p>Enjoy rewards, cashback & no hidden charges.</p>
          </div>

          <div className="product-card">
            <h3>Loans</h3>
            <p>Get instant approvals with flexible terms.</p>
          </div>

        </div>

      </div>
    </section>
  );
}
