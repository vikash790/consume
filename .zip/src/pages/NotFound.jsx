export default function NotFound() {
  return <h1 style={{ padding: "40px" }}>404 – Page Not Found</h1>;
}
