
// // import { useState } from "react";
// // import "./BulkPayment.css";

// // export default function BulkPayment() {
// //   const [transferType, setTransferType] = useState("domestic");
// //   const [rows, setRows] = useState([
// //     { name: "", account: "", code: "", amount: "", country: "", errors: {} }
// //   ]);
// //   const [globalError, setGlobalError] = useState("");

// //   // COUNTRY  FEE + SWIFT
// //   const countryInfo = {
// //     USA: { fee: 500, swift: "BOFAUS3N" },
// //     UK: { fee: 450, swift: "BARCGB22" },
// //     UAE: { fee: 300, swift: "NBEGAEAD" },
// //     Singapore: { fee: 350, swift: "DBSSSGSG" },
// //     Australia: { fee: 550, swift: "CTBAAU2S" },
// //   };

// //   // Country dropdown  Ensure unique selection for International
// //   const availableCountries = (index) => {
// //     const selected = rows.map((r) => r.country).filter(Boolean);
// //     return Object.keys(countryInfo).filter(
// //       (c) => !selected.includes(c) || rows[index].country === c
// //     );
// //   };

// //   // Add row
// //   const handleAddRow = () => {
// //     if (transferType === "international") {
// //       const used = rows.filter((r) => r.country).length;
// //       if (used >= Object.keys(countryInfo).length) {
// //         alert("No more countries available for selection.");
// //         return;
// //       }
// //     }
// //     setRows([...rows, { name: "", account: "", code: "", amount: "", country: "", errors: {} }]);
// //   };

// //   // Remove row
// //   const handleRemoveRow = (index) => {
// //     if (rows.length > 1) {
// //       setRows(rows.filter((_, i) => i !== index));
// //     }
// //   };

// //   // Handle input updates
// //   const handleChange = (index, field, value) => {
// //     const updated = [...rows];
// //     updated[index][field] = value;
// //     updated[index].errors[field] = "";

// //     // Auto-fill SWIFT code for international
// //     if (field === "country") {
// //       updated[index].code = countryInfo[value]?.swift || "";
// //     }

// //     setRows(updated);
// //   };

// //   // Per-row fee
// //   const rowFee = (row) => {
// //     if (transferType === "international" && row.country) {
// //       return countryInfo[row.country]?.fee || 0;
// //     }
// //     return 0;
// //   };

// //   // Summary calculations
// //   const subtotal = rows.reduce((sum, r) => sum + (Number(r.amount) || 0), 0);
// //   const totalFees = rows.reduce((sum, r) => sum + rowFee(r), 0);
// //   const gst = totalFees * 0.18;
// //   const totalDebit = subtotal + totalFees + gst;

// //   // VALIDATION
// //   const validate = () => {
// //     setGlobalError("");
// //     const newRows = [...rows];
// //     let ok = true;

// //     for (let i = 0; i < newRows.length; i++) {
// //       const r = newRows[i];
// //       const errors = {};

// //       if (!r.name.trim()) {
// //         errors.name = "Recipient name required";
// //         ok = false;
// //       }

// //       if (!r.account.trim()) {
// //         errors.account = "Account required";
// //         ok = false;
// //       } else if (!/^\d{6,24}$/.test(r.account)) {
// //         errors.account = "Invalid account format";
// //         ok = false;
// //       }

// //       if (!r.amount || Number(r.amount) <= 0) {
// //         errors.amount = "Enter valid amount";
// //         ok = false;
// //       }

// //       if (transferType === "domestic") {
// //         if (!r.code.trim()) {
// //           errors.code = "IFSC required";
// //           ok = false;
// //         }
// //       } else {
// //         if (!r.country) {
// //           errors.country = "Country required";
// //           ok = false;
// //         }
// //         if (!r.code.trim()) {
// //           errors.code = "SWIFT required";
// //           ok = false;
// //         }
// //       }

// //       newRows[i].errors = errors;
// //     }

// //     // Duplicate country check for international
// //     if (transferType === "international") {
// //       const all = newRows.map((r) => r.country).filter(Boolean);
// //       const duplicates = all.filter((c, idx) => all.indexOf(c) !== idx);
// //       if (duplicates.length) {
// //         setGlobalError("Each international recipient must have a unique country.");
// //         ok = false;
// //       }
// //     }

// //     setRows(newRows);
// //     return ok;
// //   };

// //   // SUBMIT
// //   const handleSubmit = (e) => {
// //     e.preventDefault();
// //     if (!validate()) return;

// //     alert("Bulk Payment Submitted Successfully! (Mock)");
// //   };

// //   // CSV EXPORT
// //   const downloadCSV = () => {
// //     let csv = "Recipient Name,Account Number,IFSC/SWIFT,Country,Amount,Fee,TotalPerRow\n";

// //     rows.forEach((r) => {
// //       const fee = rowFee(r);
// //       const totalPerRow = (Number(r.amount) || 0) + fee;

// //       csv += [
// //         `"${(r.name || "").replace(/"/g, '""')}"`,
// //         r.account || "",
// //         r.code || "",
// //         r.country || "",
// //         r.amount || "",
// //         fee,
// //         totalPerRow,
// //       ].join(",") + "\n";
// //     });

// //     csv += `\nSubtotal,,, ,${subtotal}\n`;
// //     csv += `Total Fees,,, ,${totalFees}\n`;
// //     csv += `GST (18%),,, ,${gst.toFixed(2)}\n`;
// //     csv += `Total Debit,,, ,${totalDebit.toFixed(2)}\n`;

// //     const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
// //     const url = URL.createObjectURL(blob);

// //     const a = document.createElement("a");
// //     a.href = url;
// //     a.download = "bulk-payment.csv";
// //     a.click();

// //     URL.revokeObjectURL(url);
// //   };

// //   return (
// //     <div className="bulk-wrapper">
// //       <div className="bulk-card">
// //         <h2>Bulk Payment</h2>
// //         <p className="sub">Send money to multiple recipients at once</p>

// //         <form onSubmit={handleSubmit} noValidate>
          
// //           {/* Transfer Type */}
// //           <div className="section">
// //             <label className="label">Transfer Type</label>
// //             <div className="radio-group">
// //               <label>
// //                 <input
// //                   type="radio"
// //                   value="domestic"
// //                   checked={transferType === "domestic"}
// //                   onChange={() => {
// //                     setTransferType("domestic");
// //                     setRows(rows.map(r => ({ ...r, country: "", code: "" })));
// //                   }}
// //                 />
// //                 Domestic
// //               </label>

// //               <label>
// //                 <input
// //                   type="radio"
// //                   value="international"
// //                   checked={transferType === "international"}
// //                   onChange={() => {
// //                     setTransferType("international");
// //                     setRows(rows.map(r => ({ ...r, country: "", code: "" })));
// //                   }}
// //                 />
// //                 International
// //               </label>
// //             </div>
// //           </div>

// //           <h3 className="section-title">Recipients</h3>

// //           {globalError && <div className="global-error">{globalError}</div>}

// //           {rows.map((r, i) => (
// //             <div key={i} className="row">

// //               {/* Country (only international) */}
// //               {transferType === "international" && (
// //                 <div className="field-wrap">
// //                   <label className="mini-label">Country</label>
// //                   <select
// //                     className={`input ${r.errors.country ? "error" : ""}`}
// //                     value={r.country}
// //                     onChange={(e) => handleChange(i, "country", e.target.value)}
// //                   >
// //                     <option value="">-- select --</option>
// //                     {availableCountries(i).map((c) => (
// //                       <option key={c} value={c}>{c}</option>
// //                     ))}
// //                   </select>
// //                   {r.errors.country && <div className="error-text">{r.errors.country}</div>}
// //                 </div>
// //               )}

// //               <div className="field-wrap">
// //                 <label className="mini-label">Recipient Name</label>
// //                 <input
// //                   className={`input ${r.errors.name ? "error" : ""}`}
// //                   value={r.name}
// //                   onChange={(e) => handleChange(i, "name", e.target.value)}
// //                   placeholder="Full Name"
// //                 />
// //                 {r.errors.name && <div className="error-text">{r.errors.name}</div>}
// //               </div>

// //               <div className="field-wrap">
// //                 <label className="mini-label">Account</label>
// //                 <input
// //                   className={`input ${r.errors.account ? "error" : ""}`}
// //                   value={r.account}
// //                   onChange={(e) => handleChange(i, "account", e.target.value)}
// //                   placeholder="Account Number"
// //                 />
// //                 {r.errors.account && <div className="error-text">{r.errors.account}</div>}
// //               </div>

// //               <div className="field-wrap">
// //                 <label className="mini-label">{transferType === "domestic" ? "IFSC" : "SWIFT"}</label>
// //                 <input
// //                   className={`input ${r.errors.code ? "error" : ""}`}
// //                   value={r.code}
// //                   onChange={(e) => handleChange(i, "code", e.target.value)}
// //                   placeholder={transferType === "domestic" ? "IFSC Code" : "SWIFT Code"}
// //                 />
// //                 {r.errors.code && <div className="error-text">{r.errors.code}</div>}
// //               </div>

// //               <div className="field-wrap">
// //                 <label className="mini-label">Amount</label>
// //                 <input
// //                   type="number"
// //                   className={`input ${r.errors.amount ? "error" : ""}`}
// //                   value={r.amount}
// //                   onChange={(e) => handleChange(i, "amount", e.target.value)}
// //                   placeholder="Amount"
// //                 />
// //                 {r.errors.amount && <div className="error-text">{r.errors.amount}</div>}
// //               </div>

// //               {/* Charges */}
// //               <div className="field-wrap">
// //                 <label className="mini-label">Charges</label>
// //                 <div className="charges-value">₹{rowFee(r)}</div>
// //               </div>

// //               <button type="button" className="remove-btn" onClick={() => handleRemoveRow(i)}>
// //                 Remove
// //               </button>
// //             </div>
// //           ))}

// //           <button type="button" className="add-btn" onClick={handleAddRow}>
// //             + Add Recipient
// //           </button>

// //           {/* Summary */}
// //           <div className="summary">
// //             <p>Subtotal: ₹{subtotal}</p>
// //             <p>Total Fees: ₹{totalFees}</p>
// //             <p>GST (18%): ₹{gst.toFixed(2)}</p>
// //             <h3>Total Debit: ₹{totalDebit.toFixed(2)}</h3>
// //           </div>

// //           <div className="btn-row">
// //             <button type="submit" className="btn-primary">Submit Payment</button>
// //             <button type="button" className="btn-outline" onClick={downloadCSV}>Download CSV</button>
// //           </div>

// //         </form>
// //       </div>
// //     </div>
// //   );
// // }



// // import { useState } from "react";
// // import "./BulkPayment.css";

// // const EMPTY_ROW = {
// //   name: "",
// //   address: "",
// //   account: "",
// //   code: "",
// //   amount: "",
// //   country: "",
// //   document: null,
// //   errors: {}
// // };

// // const MAX_FILE_SIZE = 1 * 1024 * 1024; // 1 MB
// // const MAX_TOTAL_SIZE = 5 * 1024 * 1024; // 5 MB
// // const ALLOWED_TYPES = [
// //   "application/pdf",
// //   "application/msword",
// //   "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
// //   "application/vnd.ms-excel",
// //   "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
// // ];

// // export default function BulkPayment() {

// //   /* ---------------- STATE ---------------- */
// //   const [paymentType, setPaymentType] = useState("individual");

// //   // ✅ MINIMUM 4 ROWS BY DEFAULT
// //   const [rows, setRows] = useState([
// //     { ...EMPTY_ROW },
// //     { ...EMPTY_ROW },
// //     { ...EMPTY_ROW },
// //     { ...EMPTY_ROW }
// //   ]);

// //   const [globalError, setGlobalError] = useState("");

// //   /* ---------------- COUNTRY CONFIG ---------------- */
// //   const countryInfo = {
// //     USA: { fee: 500, swift: "BOFAUS3N" },
// //     UK: { fee: 450, swift: "BARCGB22" },
// //     UAE: { fee: 300, swift: "NBEGAEAD" },
// //     Singapore: { fee: 350, swift: "DBSSSGSG" },
// //     Australia: { fee: 550, swift: "CTBAAU2S" }
// //   };

// //   const requiresCountry = paymentType !== "individual";

// //   /* ---------------- HELPERS ---------------- */
// //   const handleAddRow = () => {
// //     setRows([...rows, { ...EMPTY_ROW }]);
// //   };

// //   const handleRemoveRow = (index) => {
// //     if (rows.length > 4) {
// //       setRows(rows.filter((_, i) => i !== index));
// //     }
// //   };

// //   const handleChange = (index, field, value) => {
// //     const updated = [...rows];
// //     updated[index][field] = value;
// //     updated[index].errors[field] = "";

// //     if (field === "country") {
// //       updated[index].code = countryInfo[value]?.swift || "";
// //     }

// //     setRows(updated);
// //   };

// //   /* ---------------- FILE UPLOAD VALIDATION ---------------- */
// //   const getTotalFileSize = () =>
// //     rows.reduce((sum, r) => sum + (r.document?.size || 0), 0);

// //   const handleFileUpload = (index, file) => {
// //     setGlobalError("");

// //     if (!file) return;

// //     if (!ALLOWED_TYPES.includes(file.type)) {
// //       setGlobalError("Only PDF, Excel, and Word files are allowed.");
// //       return;
// //     }

// //     if (file.size > MAX_FILE_SIZE) {
// //       setGlobalError("Each file must be less than 1 MB.");
// //       return;
// //     }

// //     if (getTotalFileSize() + file.size > MAX_TOTAL_SIZE) {
// //       setGlobalError("Total uploaded file size cannot exceed 5 MB.");
// //       return;
// //     }

// //     const updated = [...rows];
// //     updated[index].document = file;
// //     setRows(updated);
// //   };

// //   /* ---------------- FEES ---------------- */
// //   const rowFee = (row) => {
// //     if (requiresCountry && row.country) {
// //       return countryInfo[row.country]?.fee || 0;
// //     }
// //     return 0;
// //   };

// //   const subtotal = rows.reduce((s, r) => s + (Number(r.amount) || 0), 0);
// //   const totalFees = rows.reduce((s, r) => s + rowFee(r), 0);
// //   const gst = totalFees * 0.18;
// //   const totalDebit = subtotal + totalFees + gst;

// //   /* ---------------- VALIDATION ---------------- */
// //   const validate = () => {
// //     setGlobalError("");
// //     let valid = true;
// //     const updated = [...rows];

// //     updated.forEach((r, i) => {
// //       const errors = {};

// //       if (!r.name.trim()) errors.name = "Beneficiary name required";
// //       if (!r.address.trim()) errors.address = "Address required";
// //       if (!r.account.trim()) errors.account = "Account / IBAN required";
// //       if (!r.amount || Number(r.amount) <= 0) errors.amount = "Invalid amount";

// //       if (requiresCountry) {
// //         if (!r.country) errors.country = "Country required";
// //         if (!r.code.trim()) errors.code = "SWIFT required";
// //       } else {
// //         if (!r.code.trim()) errors.code = "IFSC required";
// //       }

// //       updated[i].errors = errors;
// //       if (Object.keys(errors).length) valid = false;
// //     });

// //     setRows(updated);
// //     if (!valid) setGlobalError("Please fix highlighted errors.");
// //     return valid;
// //   };

// //   /* ---------------- SUBMIT ---------------- */
// //   const handleSubmit = (e) => {
// //     e.preventDefault();
// //     if (!validate()) return;

// //     alert("Bulk Payment Submitted Successfully (Mock)");

// //     setPaymentType("individual");
// //     setRows([
// //       { ...EMPTY_ROW },
// //       { ...EMPTY_ROW },
// //       { ...EMPTY_ROW },
// //       { ...EMPTY_ROW }
// //     ]);
// //   };

// //   /* ---------------- UI ---------------- */
// //   return (
// //     <div className="bulk-wrapper">
// //       <div className="bulk-card">

// //         <h2>Payments</h2>

// //         <form onSubmit={handleSubmit} noValidate>

// //           {/* PAYMENT TYPE */}
// //           <div className="section">
// //             <label className="label">Payment Type</label>
// //             <div className="radio-group">
// //               {["individual", "bulk", "salary", "payoff"].map(type => (
// //                 <label key={type}>
// //                   <input
// //                     type="radio"
// //                     checked={paymentType === type}
// //                     onChange={() => setPaymentType(type)}
// //                   />
// //                   {type.toUpperCase()}
// //                 </label>
// //               ))}
// //             </div>
// //           </div>

// //           <h3>Beneficiaries (Minimum 4 Required)</h3>
// //           {globalError && <div className="global-error">{globalError}</div>}

// //           {rows.map((r, i) => (
// //             <div key={i} className="row">

// //               {requiresCountry && (
// //                 <select
// //                   className={`input ${r.errors.country ? "error" : ""}`}
// //                   value={r.country}
// //                   onChange={e => handleChange(i, "country", e.target.value)}
// //                 >
// //                   <option value="">Country</option>
// //                   {Object.keys(countryInfo).map(c => (
// //                     <option key={c}>{c}</option>
// //                   ))}
// //                 </select>
// //               )}

// //               <input
// //                 className={`input ${r.errors.name ? "error" : ""}`}
// //                 placeholder="Beneficiary Name"
// //                 value={r.name}
// //                 onChange={e => handleChange(i, "name", e.target.value)}
// //               />

// //               <input
// //                 className={`input ${r.errors.address ? "error" : ""}`}
// //                 placeholder="Address"
// //                 value={r.address}
// //                 onChange={e => handleChange(i, "address", e.target.value)}
// //               />

// //               <input
// //                 className={`input ${r.errors.account ? "error" : ""}`}
// //                 placeholder="Account / IBAN"
// //                 value={r.account}
// //                 onChange={e => handleChange(i, "account", e.target.value)}
// //               />

// //               <input
// //                 className={`input ${r.errors.code ? "error" : ""}`}
// //                 placeholder={requiresCountry ? "SWIFT" : "IFSC"}
// //                 value={r.code}
// //                 onChange={e => handleChange(i, "code", e.target.value)}
// //               />

// //               <input
// //                 type="number"
// //                 className={`input ${r.errors.amount ? "error" : ""}`}
// //                 placeholder="Amount"
// //                 value={r.amount}
// //                 onChange={e => handleChange(i, "amount", e.target.value)}
// //               />

// //               <input
// //                 type="file"
// //                 onChange={e => handleFileUpload(i, e.target.files[0])}
// //               />

// //               <div className="charges">₹{rowFee(r)}</div>

// //               <button
// //                 type="button"
// //                 disabled={rows.length <= 4}
// //                 onClick={() => handleRemoveRow(i)}
// //               >
// //                 Remove
// //               </button>
// //             </div>
// //           ))}

// //           <button type="button" onClick={handleAddRow}>
// //             + Add Beneficiary
// //           </button>

// //           <div className="summary">
// //             <p>Subtotal: ₹{subtotal}</p>
// //             <p>Fees: ₹{totalFees}</p>
// //             <p>GST: ₹{gst.toFixed(2)}</p>
// //             <h3>Total Debit: ₹{totalDebit.toFixed(2)}</h3>
// //           </div>

// //           <div className="btn-row">
// //             <button className="btn-primary">Submit</button>
// //           </div>

// //         </form>
// //       </div>
// //     </div>
// //   );
// // }





// // import { useState } from "react";
// // import "./BulkPayment.css";

// // const EMPTY_ROW = {
// //   name: "",
// //   address: "",
// //   account: "",
// //   code: "",
// //   amount: "",
// //   country: "",
// //   document: null,
// //   errors: {}
// // };

// // const MAX_FILE_SIZE = 1 * 1024 * 1024; // 1 MB
// // const MAX_TOTAL_SIZE = 5 * 1024 * 1024; // 5 MB
// // const ALLOWED_TYPES = [
// //   "application/pdf",
// //   "application/msword",
// //   "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
// //   "application/vnd.ms-excel",
// //   "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
// // ];

// // export default function BulkPayment() {

// //   /* ---------------- STATE ---------------- */

// //   // ✅ MINIMUM 4 ROWS BY DEFAULT
// //   const [rows, setRows] = useState([
// //     { ...EMPTY_ROW },
// //     { ...EMPTY_ROW },
// //     { ...EMPTY_ROW },
// //     { ...EMPTY_ROW }
// //   ]);

// //   const [globalError, setGlobalError] = useState("");

// //   /* ---------------- COUNTRY CONFIG ---------------- */
// //   const countryInfo = {
// //     USA: { fee: 500, swift: "BOFAUS3N" },
// //     UK: { fee: 450, swift: "BARCGB22" },
// //     UAE: { fee: 300, swift: "NBEGAEAD" },
// //     Singapore: { fee: 350, swift: "DBSSSGSG" },
// //     Australia: { fee: 550, swift: "CTBAAU2S" }
// //   };

// //   /* ---------------- HELPERS ---------------- */
// //   const handleAddRow = () => {
// //     setRows([...rows, { ...EMPTY_ROW }]);
// //   };

// //   const handleRemoveRow = (index) => {
// //     if (rows.length > 4) {
// //       setRows(rows.filter((_, i) => i !== index));
// //     }
// //   };

// //   const handleChange = (index, field, value) => {
// //     const updated = [...rows];
// //     updated[index][field] = value;
// //     updated[index].errors[field] = "";

// //     if (field === "country") {
// //       updated[index].code = countryInfo[value]?.swift || "";
// //     }

// //     setRows(updated);
// //   };

// //   /* ---------------- FILE UPLOAD VALIDATION ---------------- */
// //   const getTotalFileSize = () =>
// //     rows.reduce((sum, r) => sum + (r.document?.size || 0), 0);

// //   const handleFileUpload = (index, file) => {
// //     setGlobalError("");

// //     if (!file) return;

// //     if (!ALLOWED_TYPES.includes(file.type)) {
// //       setGlobalError("Only PDF, Excel, and Word files are allowed.");
// //       return;
// //     }

// //     if (file.size > MAX_FILE_SIZE) {
// //       setGlobalError("Each file must be less than 1 MB.");
// //       return;
// //     }

// //     if (getTotalFileSize() + file.size > MAX_TOTAL_SIZE) {
// //       setGlobalError("Total uploaded file size cannot exceed 5 MB.");
// //       return;
// //     }

// //     const updated = [...rows];
// //     updated[index].document = file;
// //     setRows(updated);
// //   };

// //   /* ---------------- FEES ---------------- */
// //   const rowFee = (row) => {
// //     if (row.country) {
// //       return countryInfo[row.country]?.fee || 0;
// //     }
// //     return 0;
// //   };

// //   const subtotal = rows.reduce((s, r) => s + (Number(r.amount) || 0), 0);
// //   const totalFees = rows.reduce((s, r) => s + rowFee(r), 0);
// //   const gst = totalFees * 0.18;
// //   const totalDebit = subtotal + totalFees + gst;

// //   /* ---------------- VALIDATION ---------------- */
// //   const validate = () => {
// //     setGlobalError("");
// //     let valid = true;
// //     const updated = [...rows];

// //     updated.forEach((r, i) => {
// //       const errors = {};

// //       if (!r.name.trim()) errors.name = "Beneficiary name required";
// //       if (!r.address.trim()) errors.address = "Address required";
// //       if (!r.account.trim()) errors.account = "Account / IBAN required";
// //       if (!r.amount || Number(r.amount) <= 0) errors.amount = "Invalid amount";

// //       updated[i].errors = errors;
// //       if (Object.keys(errors).length) valid = false;
// //     });

// //     setRows(updated);
// //     if (!valid) setGlobalError("Please fix highlighted errors.");
// //     return valid;
// //   };

// //   /* ---------------- SUBMIT ---------------- */
// //   const handleSubmit = (e) => {
// //     e.preventDefault();
// //     if (!validate()) return;

// //     alert("Bulk Payment Submitted Successfully (Mock)");

// //     setRows([
// //       { ...EMPTY_ROW },
// //       { ...EMPTY_ROW },
// //       { ...EMPTY_ROW },
// //       { ...EMPTY_ROW }
// //     ]);
// //   };

// //   /* ---------------- UI ---------------- */
// //   return (
// //     <div className="bulk-wrapper">
// //       <div className="bulk-card">

// //         <h2>Payments</h2>

// //         <form onSubmit={handleSubmit} noValidate>

// //           {globalError && <div className="global-error">{globalError}</div>}

// //           {rows.map((r, i) => (
// //             <div key={i} className="row">

// //               <select
// //                 className={`input ${r.errors.country ? "error" : ""}`}
// //                 value={r.country}
// //                 onChange={e => handleChange(i, "country", e.target.value)}
// //               >
// //                 <option value="">Country</option>
// //                 {Object.keys(countryInfo).map(c => (
// //                   <option key={c}>{c}</option>
// //                 ))}
// //               </select>

// //               <input
// //                 className={`input ${r.errors.name ? "error" : ""}`}
// //                 placeholder="Beneficiary Name"
// //                 value={r.name}
// //                 onChange={e => handleChange(i, "name", e.target.value)}
// //               />

// //               <input
// //                 className={`input ${r.errors.address ? "error" : ""}`}
// //                 placeholder="Address"
// //                 value={r.address}
// //                 onChange={e => handleChange(i, "address", e.target.value)}
// //               />

// //               <input
// //                 className={`input ${r.errors.account ? "error" : ""}`}
// //                 placeholder="Account / IBAN"
// //                 value={r.account}
// //                 onChange={e => handleChange(i, "account", e.target.value)}
// //               />

// //               <input
// //                 className="input"
// //                 placeholder="SWIFT"
// //                 value={r.code}
// //                 onChange={e => handleChange(i, "code", e.target.value)}
// //               />

// //               <input
// //                 type="number"
// //                 className={`input ${r.errors.amount ? "error" : ""}`}
// //                 placeholder="Amount"
// //                 value={r.amount}
// //                 onChange={e => handleChange(i, "amount", e.target.value)}
// //               />

// //               <input
// //                 type="file"
// //                 onChange={e => handleFileUpload(i, e.target.files[0])}
// //               />

// //               <div className="charges">₹{rowFee(r)}</div>

// //               <button
// //                 type="button"
// //                 disabled={rows.length <= 4}
// //                 onClick={() => handleRemoveRow(i)}
// //               >
// //                 Remove
// //               </button>
// //             </div>
// //           ))}

// //           <button type="button" onClick={handleAddRow}>
// //             + Add Beneficiary
// //           </button>

// //           <div className="summary">
// //             <p>Subtotal: ₹{subtotal}</p>
// //             <p>Fees: ₹{totalFees}</p>
// //             <p>GST: ₹{gst.toFixed(2)}</p>
// //             <h3>Total Debit: ₹{totalDebit.toFixed(2)}</h3>
// //           </div>

// //           <div className="btn-row">
// //             <button className="btn-primary">Submit</button>
// //           </div>

// //         </form>
// //       </div>
// //     </div>
// //   );
// // }




// // import { useState, useEffect } from "react";
// // import "./BulkPayment.css";

// // /* ============================================================
// //    MOCK CORE BANKING DATA (PROTOTYPE)
// // ============================================================ */
// // const MOCK_ACCOUNTS = {
// //   ACC1001: {
// //     name: "John Doe Pvt Ltd",
// //     address: "Mumbai, India",
// //     currency: "USD",
// //     balance: 500000
// //   },
// //   ACC2002: {
// //     name: "Global Exports LLP",
// //     address: "Delhi, India",
// //     currency: "EUR",
// //     balance: 25000
// //   },
// //   ACC3003: {
// //     name: "ABC Trading Co",
// //     address: "Chennai, India",
// //     currency: "AED",
// //     balance: 0
// //   }
// // };

// // /* ============================================================
// //    CONSTANTS
// // ============================================================ */
// // const EMPTY_BENEFICIARY = {
// //   name: "",
// //   address: "",
// //   country: "USA",
// //   countryCode: "US",
// //   account: "",
// //   amount: "",
// //   paymentCurrency: "USD",
// //   fxRate: 83.25,
// //   fxPrefRate: 82.9,
// //   convertedAmount: "",
// //   purpose: "",
// //   bic: "",
// //   swift: "",
// //   document: null,
// //   errors: {}
// // };

// // const CURRENCIES = [
// //   "USD", "EUR", "CNY", "AED", "GBP",
// //   "JPY", "AUD", "CAD", "CHF", "SGD", "INR"
// // ];

// // /* ============================================================
// //    COMPONENT
// // ============================================================ */
// // export default function BulkPayment() {

// //   /* ---------------- REMITTER STATE ---------------- */
// //   const [remitter, setRemitter] = useState({
// //     accountNumber: "",
// //     accountName: "",
// //     accountAddress: "",
// //     currency: "",
// //     userName: "",
// //     availableFund: null
// //   });

// //   const [notification, setNotification] = useState("");

// //   /* ---------------- BENEFICIARIES ---------------- */
// //   const [rows, setRows] = useState([
// //     { ...EMPTY_BENEFICIARY },
// //     { ...EMPTY_BENEFICIARY },
// //     { ...EMPTY_BENEFICIARY },
// //     { ...EMPTY_BENEFICIARY }
// //   ]);

// //   const [globalError, setGlobalError] = useState("");

// //   /* ---------------- ACCOUNT LOOKUP ---------------- */
// //   const handleAccountLookup = (accountNumber) => {
// //     setNotification("");
// //     setGlobalError("");

// //     const account = MOCK_ACCOUNTS[accountNumber];

// //     if (!account) {
// //       setNotification("Invalid account number");
// //       setRemitter({
// //         accountNumber,
// //         accountName: "",
// //         accountAddress: "",
// //         currency: "",
// //         userName: remitter.userName,
// //         availableFund: null
// //       });
// //       return;
// //     }

// //     if (account.balance <= 0) {
// //       setNotification("Insufficient funds in customer account");
// //     }

// //     setRemitter(prev => ({
// //       ...prev,
// //       accountNumber,
// //       accountName: account.name,
// //       accountAddress: account.address,
// //       currency: account.currency,
// //       availableFund: account.balance
// //     }));
// //   };

// //   /* ---------------- AUTO CALCULATION ---------------- */
// //   useEffect(() => {
// //     const updated = rows.map(r => ({
// //       ...r,
// //       convertedAmount: r.amount
// //         ? (Number(r.amount) * r.fxRate).toFixed(2)
// //         : ""
// //     }));
// //     setRows(updated);
// //     // eslint-disable-next-line
// //   }, []);

// //   /* ---------------- BENEFICIARY HANDLERS ---------------- */
// //   const handleBeneficiaryChange = (index, field, value) => {
// //     const updated = [...rows];
// //     updated[index][field] = value;

// //     if (field === "amount") {
// //       updated[index].convertedAmount = (
// //         Number(value || 0) * updated[index].fxRate
// //       ).toFixed(2);
// //     }

// //     setRows(updated);
// //   };

// //   const handleAddRow = () => {
// //     setRows([...rows, { ...EMPTY_BENEFICIARY }]);
// //   };

// //   const handleRemoveRow = (index) => {
// //     if (rows.length > 4) {
// //       setRows(rows.filter((_, i) => i !== index));
// //     }
// //   };

// //   /* ---------------- TOTALS ---------------- */
// //   const totalAmount = rows.reduce((s, r) => s + (Number(r.amount) || 0), 0);
// //   const amountInWords = `${totalAmount} Dollars Only`;

// //   /* ---------------- SUBMIT ---------------- */
// //   const handleSubmit = (e) => {
// //     e.preventDefault();

// //     if (remitter.availableFund === null) {
// //       setGlobalError("Please enter a valid customer account");
// //       return;
// //     }

// //     if (totalAmount > remitter.availableFund) {
// //       setGlobalError("Insufficient funds in customer account");
// //       return;
// //     }

// //     alert("Remittance Submitted Successfully (Mock)");
// //   };

// //   /* ============================================================
// //      UI
// //   ============================================================ */
// //   return (
// //     <div className="bulk-wrapper">
// //       <div className="bulk-card">
// //         <h2>International Remittance</h2>

// //         {globalError && <div className="global-error">{globalError}</div>}
// //         {notification && <div className="global-error">{notification}</div>}

// //         <form onSubmit={handleSubmit}>

// //           {/* ================= REMITTER DETAILS ================= */}
// //           <h3>Remitter Details</h3>

// //           <div className="row">
// //             <input
// //               className="input"
// //               placeholder="Customer Account Number"
// //               value={remitter.accountNumber}
// //               onChange={(e) => handleAccountLookup(e.target.value)}
// //             />

// //             <input className="input" value={remitter.accountName} disabled />
// //             <input className="input" value={remitter.accountAddress} disabled />

// //             <select className="input" value={remitter.currency} disabled>
// //               <option value="">Currency</option>
// //               {CURRENCIES.map(c => (
// //                 <option key={c}>{c}</option>
// //               ))}
// //             </select>

// //             <input
// //               className="input"
// //               placeholder="User Name"
// //               value={remitter.userName}
// //               onChange={(e) =>
// //                 setRemitter({ ...remitter, userName: e.target.value })
// //               }
// //             />

// //             <input
// //               className="input"
// //               value={
// //                 remitter.availableFund !== null
// //                   ? `Available Fund: ${remitter.availableFund}`
// //                   : ""
// //               }
// //               disabled
// //             />
// //           </div>

// //           {/* ================= BENEFICIARY DETAILS ================= */}
// //           <h3>Beneficiary Details</h3>

// //           {rows.map((r, i) => (
// //             <div key={i} className="row">
// //               <input className="input" placeholder="Beneficiary Name" value={r.name}
// //                 onChange={e => handleBeneficiaryChange(i, "name", e.target.value)} />

// //               <input className="input" placeholder="Beneficiary Address" value={r.address}
// //                 onChange={e => handleBeneficiaryChange(i, "address", e.target.value)} />

// //               <input className="input" value={r.country} disabled />
// //               <input className="input" value={r.countryCode} disabled />

// //               <input className="input" placeholder="Account / IBAN" value={r.account}
// //                 onChange={e => handleBeneficiaryChange(i, "account", e.target.value)} />

// //               <input type="number" className="input" placeholder="Transaction Amount"
// //                 value={r.amount}
// //                 onChange={e => handleBeneficiaryChange(i, "amount", e.target.value)} />

// //               <input className="input" value={r.paymentCurrency} disabled />
// //               <input className="input" value={r.fxRate} disabled />
// //               <input className="input" value={r.fxPrefRate} disabled />
// //               <input className="input" value={r.convertedAmount} disabled />

// //               <button
// //                 type="button"
// //                 disabled={rows.length <= 4}
// //                 onClick={() => handleRemoveRow(i)}
// //               >
// //                 Remove
// //               </button>
// //             </div>
// //           ))}

// //           <button type="button" onClick={handleAddRow}>
// //             + Add Beneficiary
// //           </button>

// //           {/* ================= PAYMENT DETAILS ================= */}
// //           <h3>Payment Details</h3>

// //           <div className="summary">
// //             <p>Date & Time: {new Date().toLocaleString()}</p>
// //             <p>Total Amount: {totalAmount}</p>
// //             <p>Total Amount (Words): {amountInWords}</p>
// //             <p>Nature of Payment Valid: Y</p>
// //           </div>

// //           <div className="btn-row">
// //             <button className="btn-primary">Submit</button>
// //           </div>

// //         </form>
// //       </div>
// //     </div>
// //   );
// // }




// import { useState } from "react";
// import "./BulkPayment.css";

// /* ============================================================
//    MOCK CORE BANKING DATA (PROTOTYPE)
// ============================================================ */
// const MOCK_ACCOUNTS = {
//   ACC1001: {
//     name: "John Doe Pvt Ltd",
//     address: "Mumbai, India",
//     currency: "INR",
//     balance: 1500000
//   },
//   ACC2002: {
//     name: "Global Exports LLP",
//     address: "Delhi, India",
//     currency: "INR",
//     balance: 250000
//   },
//   ACC3003: {
//     name: "ABC Trading Co",
//     address: "Chennai, India",
//     currency: "INR",
//     balance: 0
//   }
// };

// /* ============================================================
//    FX RATE MOCK (PER CURRENCY)
// ============================================================ */
// const FX_RATES = {
//   USD: { rate: 83.25, pref: 82.9 },
//   EUR: { rate: 89.1, pref: 88.5 },
//   AED: { rate: 22.65, pref: 22.4 },
//   CNY: { rate: 11.45, pref: 11.3 },
//   GBP: { rate: 104.2, pref: 103.6 },
//   JPY: { rate: 0.56, pref: 0.54 }
// };

// const CURRENCIES = ["USD", "EUR", "AED", "CNY", "GBP", "JPY"];

// const PURPOSES = [
//   "Education",
//   "Medical",
//   "Trade",
//   "Investment",
//   "Travel",
//   "Family Maintenance",
//   "Software Services"
// ];

// /* ============================================================
//    EMPTY BENEFICIARY MODEL
// ============================================================ */
// const EMPTY_BENEFICIARY = {
//   name: "",
//   address: "",
//   country: "",
//   countryCode: "",
//   account: "",
//   amount: "",
//   beneficiaryCurrency: "",
//   fxRate: "",
//   fxPrefRate: "",
//   convertedAmount: "",
//   purpose: "",
//   bic: "",
//   swift: ""
// };

// /* ============================================================
//    COMPONENT
// ============================================================ */
// export default function BulkPayment() {

//   /* ---------------- REMITTER ---------------- */
//   const [remitter, setRemitter] = useState({
//     accountNumber: "",
//     accountName: "",
//     accountAddress: "",
//     currency: "",
//     userName: "",
//     availableFund: null
//   });

//   const [notification, setNotification] = useState("");
//   const [globalError, setGlobalError] = useState("");

//   /* ---------------- BENEFICIARIES ---------------- */
//   const [rows, setRows] = useState([
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY }
//   ]);

//   /* ============================================================
//      ACCOUNT LOOKUP (AUTO-POPULATION)
//   ============================================================ */
//   const handleAccountLookup = (accountNumber) => {
//     setNotification("");
//     setGlobalError("");

//     const account = MOCK_ACCOUNTS[accountNumber];

//     if (!account) {
//       setNotification("Invalid account number");
//       setRemitter({
//         accountNumber,
//         accountName: "",
//         accountAddress: "",
//         currency: "",
//         userName: remitter.userName,
//         availableFund: null
//       });
//       return;
//     }

//     if (account.balance <= 0) {
//       setNotification("Insufficient funds in customer account");
//     }

//     setRemitter(prev => ({
//       ...prev,
//       accountNumber,
//       accountName: account.name,
//       accountAddress: account.address,
//       currency: account.currency,
//       availableFund: account.balance
//     }));
//   };

//   /* ============================================================
//      BENEFICIARY HANDLER (PER ROW FX)
//   ============================================================ */
//   const handleBeneficiaryChange = (index, field, value) => {
//     const updated = [...rows];
//     updated[index][field] = value;

//     if (field === "beneficiaryCurrency") {
//       const fx = FX_RATES[value];
//       updated[index].fxRate = fx?.rate || "";
//       updated[index].fxPrefRate = fx?.pref || "";
//       updated[index].convertedAmount = "";
//     }

//     if (field === "amount") {
//       updated[index].convertedAmount =
//         updated[index].fxRate
//           ? (Number(value) * updated[index].fxRate).toFixed(2)
//           : "";
//     }

//     setRows(updated);
//   };

//   const handleAddRow = () => {
//     setRows([...rows, { ...EMPTY_BENEFICIARY }]);
//   };

//   const handleRemoveRow = (index) => {
//     if (rows.length > 4) {
//       setRows(rows.filter((_, i) => i !== index));
//     }
//   };

//   /* ============================================================
//      TOTAL CALCULATION (BANK CORRECT)
//   ============================================================ */
//   const totalDebit = rows.reduce(
//     (sum, r) => sum + (Number(r.convertedAmount) || 0),
//     0
//   );

//   const amountInWords = `${totalDebit.toFixed(2)} ${remitter.currency} Only`;

//   /* ============================================================
//      SUBMIT
//   ============================================================ */
//   const handleSubmit = (e) => {
//     e.preventDefault();

//     if (!remitter.accountNumber || remitter.availableFund === null) {
//       setGlobalError("Please enter a valid customer account");
//       return;
//     }

//     if (totalDebit > remitter.availableFund) {
//       setGlobalError("Insufficient funds in customer account");
//       return;
//     }

//     alert("Bulk Remittance Submitted Successfully (Mock)");
//   };

//   /* ============================================================
//      UI
//   ============================================================ */
//   return (
//     <div className="bulk-wrapper">
//       <div className="bulk-card">
//         <h2>International Bulk Remittance</h2>

//         {notification && <div className="global-error">{notification}</div>}
//         {globalError && <div className="global-error">{globalError}</div>}

//         <form onSubmit={handleSubmit}>

//           {/* ================= REMITTER ================= */}
//           <h3>Remitter Details</h3>

//           <div className="row">
//             <input
//               className="input"
//               placeholder="Customer Account Number"
//               value={remitter.accountNumber}
//               onChange={e => handleAccountLookup(e.target.value)}
//             />
//             <input className="input" value={remitter.accountName} disabled />
//             <input className="input" value={remitter.accountAddress} disabled />
//             <input className="input" value={remitter.currency} disabled />
//             <input
//               className="input"
//               placeholder="User Name"
//               value={remitter.userName}
//               onChange={e =>
//                 setRemitter({ ...remitter, userName: e.target.value })
//               }
//             />
//             <input
//               className="input"
//               value={
//                 remitter.availableFund !== null
//                   ? `Available Fund: ${remitter.availableFund}`
//                   : ""
//               }
//               disabled
//             />
//           </div>

//           {/* ================= BENEFICIARIES ================= */}
//           <h3>Beneficiary Transactions</h3>

//           {rows.map((r, i) => (
//             <div key={i} className="row">

//               <input className="input" placeholder="Beneficiary Name"
//                 value={r.name}
//                 onChange={e => handleBeneficiaryChange(i, "name", e.target.value)}
//               />

//               <input className="input" placeholder="Beneficiary Address"
//                 value={r.address}
//                 onChange={e => handleBeneficiaryChange(i, "address", e.target.value)}
//               />

//               <input className="input" placeholder="Account / IBAN"
//                 value={r.account}
//                 onChange={e => handleBeneficiaryChange(i, "account", e.target.value)}
//               />

//               <select className="input"
//                 value={r.beneficiaryCurrency}
//                 onChange={e =>
//                   handleBeneficiaryChange(i, "beneficiaryCurrency", e.target.value)
//                 }>
//                 <option value="">Currency</option>
//                 {CURRENCIES.map(c => (
//                   <option key={c}>{c}</option>
//                 ))}
//               </select>

//               <input type="number" className="input" placeholder="Amount"
//                 value={r.amount}
//                 onChange={e => handleBeneficiaryChange(i, "amount", e.target.value)}
//               />

//               <input className="input" placeholder="FX Rate" value={r.fxRate} disabled />
//               <input className="input" placeholder="Pref FX" value={r.fxPrefRate} disabled />
//               <input className="input" placeholder="Converted Amount"
//                 value={r.convertedAmount} disabled />

//               {/* ✅ PURPOSE OF REMITTANCE */}
//               <select className="input"
//                 value={r.purpose}
//                 onChange={e => handleBeneficiaryChange(i, "purpose", e.target.value)}>
//                 <option value="">Purpose of Remittance</option>
//                 {PURPOSES.map(p => (
//                   <option key={p}>{p}</option>
//                 ))}
//               </select>

//               {/* ✅ BIC */}
//               <input className="input" placeholder="BIC"
//                 value={r.bic}
//                 onChange={e => handleBeneficiaryChange(i, "bic", e.target.value)}
//               />

//               {/* ✅ SWIFT */}
//               <input className="input" placeholder="SWIFT"
//                 value={r.swift}
//                 onChange={e => handleBeneficiaryChange(i, "swift", e.target.value)}
//               />

//               <button
//                 type="button"
//                 disabled={rows.length <= 4}
//                 onClick={() => handleRemoveRow(i)}
//               >
//                 Remove
//               </button>
//             </div>
//           ))}

//           <button type="button" onClick={handleAddRow}>
//             + Add Beneficiary
//           </button>

//           {/* ================= SUMMARY ================= */}
//           <h3>Payment Summary</h3>

//           <div className="summary">
//             <p>Date & Time: {new Date().toLocaleString()}</p>
//             <p>Total Debit ({remitter.currency}): {totalDebit.toFixed(2)}</p>
//             <p>Total Amount (Words): {amountInWords}</p>
//             <p>Nature of Payment Valid: Y</p>
//           </div>

//           <div className="btn-row">
//             <button className="btn-primary">Submit</button>
//           </div>

//         </form>
//       </div>
//     </div>
//   );
// }




// import { useState } from "react";
// import "./BulkPayment.css";

// /* ============================================================
//    MOCK CORE BANKING DATA (PROTOTYPE)
// ============================================================ */
// const MOCK_ACCOUNTS = {
//   ACC1001: {
//     name: "John Doe Pvt Ltd",
//     address: "Mumbai, India",
//     currency: "INR",
//     balance: 1500000
//   },
//   ACC2002: {
//     name: "Global Exports LLP",
//     address: "Delhi, India",
//     currency: "INR",
//     balance: 250000
//   },
//   ACC3003: {
//     name: "ABC Trading Co",
//     address: "Chennai, India",
//     currency: "INR",
//     balance: 0
//   }
// };

// /* ============================================================
//    FX RATE MOCK
// ============================================================ */
// const FX_RATES = {
//   USD: { rate: 83.25, pref: 82.9 },
//   EUR: { rate: 89.1, pref: 88.5 },
//   AED: { rate: 22.65, pref: 22.4 },
//   CNY: { rate: 11.45, pref: 11.3 },
//   GBP: { rate: 104.2, pref: 103.6 },
//   JPY: { rate: 0.56, pref: 0.54 }
// };

// const CURRENCIES = ["USD", "EUR", "AED", "CNY", "GBP", "JPY"];

// const PURPOSES = [
//   "Education",
//   "Medical",
//   "Trade",
//   "Investment",
//   "Travel",
//   "Family Maintenance",
//   "Software Services"
// ];

// /* ============================================================
//    EMPTY BENEFICIARY MODEL
// ============================================================ */
// const EMPTY_BENEFICIARY = {
//   name: "",
//   address: "",
//   account: "",
//   amount: "",
//   beneficiaryCurrency: "",
//   fxRate: "",
//   fxPrefRate: "",
//   convertedAmount: "",
//   purpose: "",
//   bic: "",
//   swift: "",
//   errors: {}
// };

// /* ============================================================
//    COMPONENT
// ============================================================ */
// export default function BulkPayment() {

//   /* ---------------- REMITTER ---------------- */
//   const [remitter, setRemitter] = useState({
//     accountNumber: "",
//     accountName: "",
//     accountAddress: "",
//     currency: "",
//     userName: "",
//     availableFund: null
//   });

//   const [notification, setNotification] = useState("");
//   const [globalError, setGlobalError] = useState("");

//   /* ---------------- BENEFICIARIES ---------------- */
//   const [rows, setRows] = useState([
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY }
//   ]);

//   /* ============================================================
//      ACCOUNT LOOKUP
//   ============================================================ */
//   const handleAccountLookup = (accountNumber) => {
//     setNotification("");
//     setGlobalError("");

//     const account = MOCK_ACCOUNTS[accountNumber];

//     if (!account) {
//       setNotification("Invalid account number");
//       setRemitter({
//         accountNumber,
//         accountName: "",
//         accountAddress: "",
//         currency: "",
//         userName: remitter.userName,
//         availableFund: null
//       });
//       return;
//     }

//     if (account.balance <= 0) {
//       setNotification("Insufficient funds in customer account");
//     }

//     setRemitter(prev => ({
//       ...prev,
//       accountNumber,
//       accountName: account.name,
//       accountAddress: account.address,
//       currency: account.currency,
//       availableFund: account.balance
//     }));
//   };

//   /* ============================================================
//      BENEFICIARY CHANGE
//   ============================================================ */
//   const handleBeneficiaryChange = (index, field, value) => {
//     const updated = [...rows];
//     updated[index][field] = value;
//     updated[index].errors[field] = "";

//     if (field === "beneficiaryCurrency") {
//       const fx = FX_RATES[value];
//       updated[index].fxRate = fx?.rate || "";
//       updated[index].fxPrefRate = fx?.pref || "";
//       updated[index].convertedAmount = "";
//     }

//     if (field === "amount") {
//       updated[index].convertedAmount =
//         updated[index].fxRate && Number(value) > 0
//           ? (Number(value) * updated[index].fxRate).toFixed(2)
//           : "";
//     }

//     setRows(updated);
//   };

//   const handleAddRow = () => {
//     setRows([...rows, { ...EMPTY_BENEFICIARY }]);
//   };

//   const handleRemoveRow = (index) => {
//     if (rows.length > 4) {
//       setRows(rows.filter((_, i) => i !== index));
//     }
//   };

//   /* ============================================================
//      VALIDATION
//   ============================================================ */
//   const validateForm = () => {
//     let valid = true;
//     const updated = [...rows];

//     updated.forEach((r, i) => {
//       const errors = {};

//       if (!r.amount || Number(r.amount) <= 0)
//         errors.amount = "Amount must be greater than zero";

//       if (!r.purpose)
//         errors.purpose = "Purpose of remittance is required";

//       if (!r.bic.trim())
//         errors.bic = "BIC is required";

//       if (!r.swift.trim())
//         errors.swift = "SWIFT is required";

//       updated[i].errors = errors;
//       if (Object.keys(errors).length) valid = false;
//     });

//     setRows(updated);
//     return valid;
//   };

//   /* ============================================================
//      TOTALS
//   ============================================================ */
//   const totalDebit = rows.reduce(
//     (sum, r) => sum + (Number(r.convertedAmount) || 0),
//     0
//   );

//   const amountInWords = `${totalDebit.toFixed(2)} ${remitter.currency} Only`;

//   /* ============================================================
//      SUBMIT
//   ============================================================ */
//   const handleSubmit = (e) => {
//     e.preventDefault();
//     setGlobalError("");

//     if (!validateForm()) {
//       setGlobalError("Please fix the highlighted errors.");
//       return;
//     }

//     if (!remitter.accountNumber || remitter.availableFund === null) {
//       setGlobalError("Please enter a valid customer account");
//       return;
//     }

//     if (totalDebit > remitter.availableFund) {
//       setGlobalError("Insufficient funds in customer account");
//       return;
//     }

//     alert("Bulk Remittance Submitted Successfully (Mock)");
//   };

//   /* ============================================================
//      UI
//   ============================================================ */
//   return (
//     <div className="bulk-wrapper">
//       <div className="bulk-card">
//         <h2>International Bulk Remittance</h2>

//         {notification && <div className="global-error">{notification}</div>}
//         {globalError && <div className="global-error">{globalError}</div>}

//         <form onSubmit={handleSubmit}>

//           <h3>Remitter Details</h3>
//           <div className="row">
//             <input className="input" placeholder="Customer Account Number"
//               value={remitter.accountNumber}
//               onChange={e => handleAccountLookup(e.target.value)} />
//             <input className="input" value={remitter.accountName} disabled />
//             <input className="input" value={remitter.accountAddress} disabled />
//             <input className="input" value={remitter.currency} disabled />
//             <input className="input" placeholder="User Name"
//               value={remitter.userName}
//               onChange={e => setRemitter({ ...remitter, userName: e.target.value })} />
//             <input className="input"
//               value={remitter.availableFund !== null ? `Available Fund: ${remitter.availableFund}` : ""}
//               disabled />
//           </div>

//           <h3>Beneficiary Transactions</h3>

//           {rows.map((r, i) => (
//             <div key={i} className="row">

//               <input className="input" placeholder="Beneficiary Name"
//                 value={r.name}
//                 onChange={e => handleBeneficiaryChange(i, "name", e.target.value)} />

//               <input className="input" placeholder="Beneficiary Address"
//                 value={r.address}
//                 onChange={e => handleBeneficiaryChange(i, "address", e.target.value)} />

//               <input className="input" placeholder="Account / IBAN"
//                 value={r.account}
//                 onChange={e => handleBeneficiaryChange(i, "account", e.target.value)} />

//               <select className="input"
//                 value={r.beneficiaryCurrency}
//                 onChange={e => handleBeneficiaryChange(i, "beneficiaryCurrency", e.target.value)}>
//                 <option value="">Currency</option>
//                 {CURRENCIES.map(c => <option key={c}>{c}</option>)}
//               </select>

//               <input type="number" min="0.01"
//                 className={`input ${r.errors.amount ? "error" : ""}`}
//                 placeholder="Amount"
//                 value={r.amount}
//                 onChange={e => handleBeneficiaryChange(i, "amount", e.target.value)} />
//               {r.errors.amount && <div className="error-text">{r.errors.amount}</div>}

//               <input className="input" value={r.fxRate} disabled />
//               <input className="input" value={r.fxPrefRate} disabled />
//               <input className="input" value={r.convertedAmount} disabled />

//               <select className={`input ${r.errors.purpose ? "error" : ""}`}
//                 value={r.purpose}
//                 onChange={e => handleBeneficiaryChange(i, "purpose", e.target.value)}>
//                 <option value="">Purpose of Remittance</option>
//                 {PURPOSES.map(p => <option key={p}>{p}</option>)}
//               </select>
//               {r.errors.purpose && <div className="error-text">{r.errors.purpose}</div>}

//               <input className={`input ${r.errors.bic ? "error" : ""}`}
//                 placeholder="BIC"
//                 value={r.bic}
//                 onChange={e => handleBeneficiaryChange(i, "bic", e.target.value)} />
//               {r.errors.bic && <div className="error-text">{r.errors.bic}</div>}

//               <input className={`input ${r.errors.swift ? "error" : ""}`}
//                 placeholder="SWIFT"
//                 value={r.swift}
//                 onChange={e => handleBeneficiaryChange(i, "swift", e.target.value)} />
//               {r.errors.swift && <div className="error-text">{r.errors.swift}</div>}

//               <button type="button"
//                 disabled={rows.length <= 4}
//                 onClick={() => handleRemoveRow(i)}>
//                 Remove
//               </button>
//             </div>
//           ))}

//           <button type="button" onClick={handleAddRow}>+ Add Beneficiary</button>

//           <h3>Payment Summary</h3>
//           <div className="summary">
//             <p>Date & Time: {new Date().toLocaleString()}</p>
//             <p>Total Debit ({remitter.currency}): {totalDebit.toFixed(2)}</p>
//             <p>Total Amount (Words): {amountInWords}</p>
//             <p>Nature of Payment Valid: Y</p>
//           </div>

//           <div className="btn-row">
//             <button className="btn-primary">Submit</button>
//           </div>

//         </form>
//       </div>
//     </div>
//   );
// }



// import { useState } from "react";
// import "./BulkPayment.css";

// /* ============================================================
//    MOCK CORE BANKING DATA
// ============================================================ */
// const MOCK_ACCOUNTS = {
//   ACC1001: {
//     name: "John Doe Pvt Ltd",
//     address: "Mumbai, India",
//     currency: "INR",
//     balance: 1500000
//   },
//   ACC2002: {
//     name: "Global Exports LLP",
//     address: "Delhi, India",
//     currency: "INR",
//     balance: 250000
//   }
// };

// /* ============================================================
//    FX RATES
// ============================================================ */
// const FX_RATES = {
//   USD: { rate: 83.25, pref: 82.9 },
//   EUR: { rate: 89.1, pref: 88.5 },
//   AED: { rate: 22.65, pref: 22.4 },
//   CNY: { rate: 11.45, pref: 11.3 },
//   GBP: { rate: 104.2, pref: 103.6 },
//   JPY: { rate: 0.56, pref: 0.54 }
// };

// const CURRENCIES = ["USD", "EUR", "AED", "CNY", "GBP", "JPY"];

// const PURPOSES = [
//   "Education",
//   "Medical",
//   "Trade",
//   "Investment",
//   "Travel",
//   "Family Maintenance",
//   "Software Services"
// ];

// /* ============================================================
//    EMPTY BENEFICIARY
// ============================================================ */
// const EMPTY_BENEFICIARY = {
//   name: "",
//   address: "",
//   account: "",
//   beneficiaryCurrency: "",
//   amount: "",
//   fxRate: "",
//   fxPrefRate: "",
//   convertedAmount: "",
//   purpose: "",
//   bic: "",
//   swift: "",
//   errors: {}
// };

// /* ============================================================
//    COMPONENT
// ============================================================ */
// export default function BulkPayment() {

//   /* ---------------- REMITTER ---------------- */
//   const [remitter, setRemitter] = useState({
//     accountNumber: "",
//     accountName: "",
//     accountAddress: "",
//     currency: "",
//     availableFund: null
//   });

//   const [rows, setRows] = useState([
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY }
//   ]);

//   const [globalError, setGlobalError] = useState("");

//   /* ============================================================
//      ACCOUNT LOOKUP
//   ============================================================ */
//   const handleAccountLookup = (value) => {
//     const acc = MOCK_ACCOUNTS[value];

//     if (!acc) {
//       setRemitter({
//         accountNumber: value,
//         accountName: "",
//         accountAddress: "",
//         currency: "",
//         availableFund: null
//       });
//       return;
//     }

//     setRemitter({
//       accountNumber: value,
//       accountName: acc.name,
//       accountAddress: acc.address,
//       currency: acc.currency,
//       availableFund: acc.balance
//     });
//   };

//   /* ============================================================
//      FIELD CHANGE
//   ============================================================ */
//   const handleChange = (i, field, value) => {
//     const updated = [...rows];
//     updated[i][field] = value;
//     updated[i].errors[field] = false;

//     if (field === "beneficiaryCurrency") {
//       const fx = FX_RATES[value];
//       updated[i].fxRate = fx?.rate || "";
//       updated[i].fxPrefRate = fx?.pref || "";
//       updated[i].convertedAmount = "";
//     }

//     if (field === "amount") {
//       updated[i].convertedAmount =
//         updated[i].fxRate && Number(value) > 0
//           ? (Number(value) * updated[i].fxRate).toFixed(2)
//           : "";
//     }

//     setRows(updated);
//   };

//   /* ============================================================
//      ADD / REMOVE BENEFICIARY
//   ============================================================ */
//   const handleAddRow = () => {
//     setRows([...rows, { ...EMPTY_BENEFICIARY }]);
//   };

//   /* ============================================================
//      VALIDATION (GLOBAL ONLY)
//   ============================================================ */
//   const validateForm = () => {
//     let valid = true;
//     const updated = [...rows];

//     updated.forEach(r => {
//       r.errors = {};

//       Object.keys(r).forEach(key => {
//         if (key !== "errors") {
//           if (
//             r[key] === "" ||
//             (key === "amount" && Number(r[key]) <= 0)
//           ) {
//             r.errors[key] = true;
//             valid = false;
//           }
//         }
//       });
//     });

//     setRows(updated);
//     setGlobalError(valid ? "" : "Please fill all required details");
//     return valid;
//   };

//   /* ============================================================
//      TOTAL
//   ============================================================ */
//   const totalDebit = rows.reduce(
//     (sum, r) => sum + (Number(r.convertedAmount) || 0),
//     0
//   );

//   /* ============================================================
//      SUBMIT
//   ============================================================ */
//   const handleSubmit = (e) => {
//     e.preventDefault();

//     if (!validateForm()) return;

//     if (!remitter.accountNumber || remitter.availableFund === null) {
//       setGlobalError("Please fill all required details");
//       return;
//     }

//     if (totalDebit > remitter.availableFund) {
//       setGlobalError("Please fill all required details");
//       return;
//     }

//     alert("Bulk Remittance Submitted Successfully (Mock)");
//   };

//   /* ============================================================
//      UI
//   ============================================================ */
//   return (
//     <div className="bulk-wrapper">
//       <div className="bulk-card">

//         <h2>International Bulk Remittance</h2>

//         {globalError && <div className="global-error">{globalError}</div>}

//         <form onSubmit={handleSubmit}>

//           {/* ================= REMITTER ================= */}
//           <h3>Remitter Details</h3>
//           <div className="row">
//             <input
//               className={`input ${!remitter.accountName && remitter.accountNumber ? "error" : ""}`}
//               placeholder="Customer Account Number"
//               value={remitter.accountNumber}
//               onChange={e => handleAccountLookup(e.target.value)}
//             />
//             <input className="input" value={remitter.accountName} disabled />
//             <input className="input" value={remitter.accountAddress} disabled />
//             <input className="input" value={remitter.currency} disabled />
//             <input
//               className="input"
//               value={
//                 remitter.availableFund !== null
//                   ? `Available Fund: ${remitter.availableFund}`
//                   : ""
//               }
//               disabled
//             />
//           </div>

//           {/* ================= BENEFICIARIES ================= */}
//           <h3>Beneficiary Transactions</h3>

//           {rows.map((r, i) => (
//             <div key={i} className="row">

//               <input className={`input ${r.errors.name ? "error" : ""}`}
//                 placeholder="Beneficiary Name"
//                 value={r.name}
//                 onChange={e => handleChange(i, "name", e.target.value)}
//               />

//               <input className={`input ${r.errors.address ? "error" : ""}`}
//                 placeholder="Beneficiary Address"
//                 value={r.address}
//                 onChange={e => handleChange(i, "address", e.target.value)}
//               />

//               <input className={`input ${r.errors.account ? "error" : ""}`}
//                 placeholder="Account / IBAN"
//                 value={r.account}
//                 onChange={e => handleChange(i, "account", e.target.value)}
//               />

//               <select className={`input ${r.errors.beneficiaryCurrency ? "error" : ""}`}
//                 value={r.beneficiaryCurrency}
//                 onChange={e => handleChange(i, "beneficiaryCurrency", e.target.value)}
//               >
//                 <option value="">Currency</option>
//                 {CURRENCIES.map(c => <option key={c}>{c}</option>)}
//               </select>

//               <input type="number"
//                 className={`input ${r.errors.amount ? "error" : ""}`}
//                 placeholder="Amount"
//                 value={r.amount}
//                 onChange={e => handleChange(i, "amount", e.target.value)}
//               />

//               <input className="input" value={r.fxRate} disabled />
//               <input className="input" value={r.fxPrefRate} disabled />
//               <input className="input" value={r.convertedAmount} disabled />

//               <select className={`input ${r.errors.purpose ? "error" : ""}`}
//                 value={r.purpose}
//                 onChange={e => handleChange(i, "purpose", e.target.value)}
//               >
//                 <option value="">Purpose</option>
//                 {PURPOSES.map(p => <option key={p}>{p}</option>)}
//               </select>

//               <input className={`input ${r.errors.bic ? "error" : ""}`}
//                 placeholder="BIC"
//                 value={r.bic}
//                 onChange={e => handleChange(i, "bic", e.target.value)}
//               />

//               <input className={`input ${r.errors.swift ? "error" : ""}`}
//                 placeholder="SWIFT"
//                 value={r.swift}
//                 onChange={e => handleChange(i, "swift", e.target.value)}
//               />

//             </div>
//           ))}

//           {/* ✅ ADD BENEFICIARY */}
//           <button type="button" onClick={handleAddRow}>
//             + Add Beneficiary
//           </button>

//           <div className="btn-row">
//             <button className="btn-primary">Submit</button>
//           </div>

//         </form>
//       </div>
//     </div>
//   );
// }



// import { useState } from "react";
// import "./BulkPayment.css";

// /* ============================================================
//    MOCK CORE BANKING DATA
// ============================================================ */
// const MOCK_ACCOUNTS = {
//   ACC1001: {
//     name: "John Doe Pvt Ltd",
//     address: "Mumbai, India",
//     currency: "INR",
//     balance: 1500000
//   },
//   ACC2002: {
//     name: "Global Exports LLP",
//     address: "Delhi, India",
//     currency: "INR",
//     balance: 250000
//   }
// };

// /* ============================================================
//    FX RATES
// ============================================================ */
// const FX_RATES = {
//   USD: { rate: 83.25, pref: 82.9 },
//   EUR: { rate: 89.1, pref: 88.5 },
//   AED: { rate: 22.65, pref: 22.4 },
//   CNY: { rate: 11.45, pref: 11.3 },
//   GBP: { rate: 104.2, pref: 103.6 },
//   JPY: { rate: 0.56, pref: 0.54 }
// };

// const CURRENCIES = ["USD", "EUR", "AED", "CNY", "GBP", "JPY"];

// const PURPOSES = [
//   "Education",
//   "Medical",
//   "Trade",
//   "Investment",
//   "Travel",
//   "Family Maintenance",
//   "Software Services"
// ];

// /* ============================================================
//    FILE UPLOAD CONFIG
// ============================================================ */
// const MAX_FILE_SIZE = 1 * 1024 * 1024; // 1 MB
// const MAX_TOTAL_SIZE = 5 * 1024 * 1024; // 5 MB

// const ALLOWED_TYPES = [
//   "application/pdf",
//   "application/msword",
//   "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
//   "application/vnd.ms-excel",
//   "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
// ];

// /* ============================================================
//    EMPTY BENEFICIARY
// ============================================================ */
// const EMPTY_BENEFICIARY = {
//   name: "",
//   address: "",
//   account: "",
//   beneficiaryCurrency: "",
//   amount: "",
//   fxRate: "",
//   fxPrefRate: "",
//   convertedAmount: "",
//   purpose: "",
//   bic: "",
//   swift: "",
//   errors: {}
// };

// /* ============================================================
//    COMPONENT
// ============================================================ */
// export default function BulkPayment() {

//   /* ---------------- REMITTER ---------------- */
//   const [remitter, setRemitter] = useState({
//     accountNumber: "",
//     accountName: "",
//     accountAddress: "",
//     currency: "",
//     availableFund: null
//   });

//   const [rows, setRows] = useState([
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY }
//   ]);

//   const [attachments, setAttachments] = useState([]);
//   const [globalError, setGlobalError] = useState("");

//   /* ============================================================
//      ACCOUNT LOOKUP
//   ============================================================ */
//   const handleAccountLookup = (value) => {
//     const acc = MOCK_ACCOUNTS[value];

//     if (!acc) {
//       setRemitter({
//         accountNumber: value,
//         accountName: "",
//         accountAddress: "",
//         currency: "",
//         availableFund: null
//       });
//       return;
//     }

//     setRemitter({
//       accountNumber: value,
//       accountName: acc.name,
//       accountAddress: acc.address,
//       currency: acc.currency,
//       availableFund: acc.balance
//     });
//   };

//   /* ============================================================
//      FIELD CHANGE
//   ============================================================ */
//   const handleChange = (i, field, value) => {
//     const updated = [...rows];
//     updated[i][field] = value;
//     updated[i].errors[field] = false;

//     if (field === "beneficiaryCurrency") {
//       const fx = FX_RATES[value];
//       updated[i].fxRate = fx?.rate || "";
//       updated[i].fxPrefRate = fx?.pref || "";
//       updated[i].convertedAmount = "";
//     }

//     if (field === "amount") {
//       updated[i].convertedAmount =
//         updated[i].fxRate && Number(value) > 0
//           ? (Number(value) * updated[i].fxRate).toFixed(2)
//           : "";
//     }

//     setRows(updated);
//   };

//   /* ============================================================
//      ADD BENEFICIARY
//   ============================================================ */
//   const handleAddRow = () => {
//     setRows([...rows, { ...EMPTY_BENEFICIARY }]);
//   };

//   /* ============================================================
//      FILE UPLOAD (OPTIONAL)
//   ============================================================ */
//   const handleFileUpload = (e) => {
//     const files = Array.from(e.target.files);
//     let totalSize = attachments.reduce((s, f) => s + f.size, 0);

//     for (const file of files) {
//       if (!ALLOWED_TYPES.includes(file.type)) {
//         setGlobalError("Only PDF, Word, and Excel files are allowed");
//         return;
//       }

//       if (file.size > MAX_FILE_SIZE) {
//         setGlobalError("Each file must be less than 1 MB");
//         return;
//       }

//       totalSize += file.size;
//       if (totalSize > MAX_TOTAL_SIZE) {
//         setGlobalError("Total attachment size must not exceed 5 MB");
//         return;
//       }
//     }

//     setGlobalError("");
//     setAttachments(prev => [...prev, ...files]);
//   };

//   /* ============================================================
//      VALIDATION (GLOBAL ONLY)
//   ============================================================ */
//   const validateForm = () => {
//     let valid = true;
//     const updated = [...rows];

//     updated.forEach(r => {
//       r.errors = {};

//       Object.keys(r).forEach(key => {
//         if (key !== "errors") {
//           if (
//             r[key] === "" ||
//             (key === "amount" && Number(r[key]) <= 0)
//           ) {
//             r.errors[key] = true;
//             valid = false;
//           }
//         }
//       });
//     });

//     setRows(updated);
//     setGlobalError(valid ? "" : "Please fill all required details");
//     return valid;
//   };

//   /* ============================================================
//      TOTAL
//   ============================================================ */
//   const totalDebit = rows.reduce(
//     (sum, r) => sum + (Number(r.convertedAmount) || 0),
//     0
//   );

//   /* ============================================================
//      SUBMIT
//   ============================================================ */
//   const handleSubmit = (e) => {
//     e.preventDefault();

//     if (!validateForm()) return;

//     if (!remitter.accountNumber || remitter.availableFund === null) {
//       setGlobalError("Please fill all required details");
//       return;
//     }

//     if (totalDebit > remitter.availableFund) {
//       setGlobalError("Please fill all required details");
//       return;
//     }

//     alert("Bulk Remittance Submitted Successfully (Mock)");
//   };

//   /* ============================================================
//      UI
//   ============================================================ */
//   return (
//     <div className="bulk-wrapper">
//       <div className="bulk-card">

//         <h2>International Bulk Remittance</h2>

//         {globalError && <div className="global-error">{globalError}</div>}

//         <form onSubmit={handleSubmit}>

//           <h3>Remitter Details</h3>
//           <div className="row">
//             <input
//               className={`input ${!remitter.accountName && remitter.accountNumber ? "error" : ""}`}
//               placeholder="Customer Account Number"
//               value={remitter.accountNumber}
//               onChange={e => handleAccountLookup(e.target.value)}
//             />
//             <input className="input" value={remitter.accountName} disabled />
//             <input className="input" value={remitter.accountAddress} disabled />
//             <input className="input" value={remitter.currency} disabled />
//             <input
//               className="input"
//               value={
//                 remitter.availableFund !== null
//                   ? `Available Fund: ${remitter.availableFund}`
//                   : ""
//               }
//               disabled
//             />
//           </div>

//           <h3>Beneficiary Transactions</h3>

//           {rows.map((r, i) => (
//             <div key={i} className="row">

//               <input className={`input ${r.errors.name ? "error" : ""}`}
//                 placeholder="Beneficiary Name"
//                 value={r.name}
//                 onChange={e => handleChange(i, "name", e.target.value)}
//               />

//               <input className={`input ${r.errors.address ? "error" : ""}`}
//                 placeholder="Beneficiary Address"
//                 value={r.address}
//                 onChange={e => handleChange(i, "address", e.target.value)}
//               />

//               <input className={`input ${r.errors.account ? "error" : ""}`}
//                 placeholder="Account / IBAN"
//                 value={r.account}
//                 onChange={e => handleChange(i, "account", e.target.value)}
//               />

//               <select className={`input ${r.errors.beneficiaryCurrency ? "error" : ""}`}
//                 value={r.beneficiaryCurrency}
//                 onChange={e => handleChange(i, "beneficiaryCurrency", e.target.value)}
//               >
//                 <option value="">Currency</option>
//                 {CURRENCIES.map(c => <option key={c}>{c}</option>)}
//               </select>

//               <input type="number"
//                 className={`input ${r.errors.amount ? "error" : ""}`}
//                 placeholder="Amount"
//                 value={r.amount}
//                 onChange={e => handleChange(i, "amount", e.target.value)}
//               />

//               <input className="input" value={r.fxRate} disabled />
//               <input className="input" value={r.fxPrefRate} disabled />
//               <input className="input" value={r.convertedAmount} disabled />

//               <select className={`input ${r.errors.purpose ? "error" : ""}`}
//                 value={r.purpose}
//                 onChange={e => handleChange(i, "purpose", e.target.value)}
//               >
//                 <option value="">Purpose</option>
//                 {PURPOSES.map(p => <option key={p}>{p}</option>)}
//               </select>

//               <input className={`input ${r.errors.bic ? "error" : ""}`}
//                 placeholder="BIC"
//                 value={r.bic}
//                 onChange={e => handleChange(i, "bic", e.target.value)}
//               />

//               <input className={`input ${r.errors.swift ? "error" : ""}`}
//                 placeholder="SWIFT"
//                 value={r.swift}
//                 onChange={e => handleChange(i, "swift", e.target.value)}
//               />

//             </div>
//           ))}

//           <button type="button" onClick={handleAddRow}>
//             + Add Beneficiary
//           </button>

//           {/* ================= FILE UPLOAD (OPTIONAL) ================= */}
//           <h3>Supporting Documents (Optional)</h3>
//           <p className="upload-info">
//             Allowed: PDF, Word, Excel | Max 1 MB per file | Max 5 MB total
//           </p>

//           <input
//             type="file"
//             multiple
//             onChange={handleFileUpload}
//           />

//           <div className="btn-row">
//             <button className="btn-primary">Submit</button>
//           </div>

//         </form>
//       </div>
//     </div>
//   );
// }



// import { useState } from "react";
// import "./BulkPayment.css";

// /* ============================================================
//    MOCK CORE BANKING DATA
// ============================================================ */
// const MOCK_ACCOUNTS = {
//   ACC1001: {
//     name: "John Doe Pvt Ltd",
//     address: "Mumbai, India",
//     currency: "INR",
//     balance: 1500000
//   },
//   ACC2002: {
//     name: "Global Exports LLP",
//     address: "Delhi, India",
//     currency: "INR",
//     balance: 250000
//   }
// };

// /* ============================================================
//    FX RATES
// ============================================================ */
// const FX_RATES = {
//   USD: { rate: 83.25, pref: 82.9 },
//   EUR: { rate: 89.1, pref: 88.5 },
//   AED: { rate: 22.65, pref: 22.4 },
//   CNY: { rate: 11.45, pref: 11.3 },
//   GBP: { rate: 104.2, pref: 103.6 },
//   JPY: { rate: 0.56, pref: 0.54 }
// };

// const CURRENCIES = ["USD", "EUR", "AED", "CNY", "GBP", "JPY"];

// const PURPOSES = [
//   "Education",
//   "Medical",
//   "Trade",
//   "Investment",
//   "Travel",
//   "Family Maintenance",
//   "Software Services"
// ];

// /* ============================================================
//    FILE CONFIG
// ============================================================ */
// const MAX_FILE_SIZE = 1 * 1024 * 1024;
// const MAX_TOTAL_SIZE = 5 * 1024 * 1024;

// const ALLOWED_TYPES = [
//   "application/pdf",
//   "application/msword",
//   "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
//   "application/vnd.ms-excel",
//   "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
// ];

// /* ============================================================
//    EMPTY BENEFICIARY
// ============================================================ */
// const EMPTY_BENEFICIARY = {
//   name: "",
//   address: "",
//   account: "",
//   beneficiaryCurrency: "",
//   amount: "",
//   fxRate: "",
//   fxPrefRate: "",
//   convertedAmount: "",
//   purpose: "",
//   bic: "",
//   swift: "",
//   documents: [],
//   errors: {}
// };

// /* ============================================================
//    COMPONENT
// ============================================================ */
// export default function BulkPayment() {

//   /* ---------------- REMITTER ---------------- */
//   const [remitter, setRemitter] = useState({
//     accountNumber: "",
//     accountName: "",
//     accountAddress: "",
//     currency: "",
//     availableFund: null
//   });

//   const [rows, setRows] = useState([
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY }
//   ]);

//   const [globalError, setGlobalError] = useState("");

//   /* ============================================================
//      ACCOUNT LOOKUP
//   ============================================================ */
//   const handleAccountLookup = (value) => {
//     const acc = MOCK_ACCOUNTS[value];

//     if (!acc) {
//       setRemitter({
//         accountNumber: value,
//         accountName: "",
//         accountAddress: "",
//         currency: "",
//         availableFund: null
//       });
//       return;
//     }

//     setRemitter({
//       accountNumber: value,
//       accountName: acc.name,
//       accountAddress: acc.address,
//       currency: acc.currency,
//       availableFund: acc.balance
//     });
//   };

//   /* ============================================================
//      FIELD CHANGE
//   ============================================================ */
//   const handleChange = (i, field, value) => {
//     const updated = [...rows];
//     updated[i][field] = value;
//     updated[i].errors[field] = false;

//     if (field === "beneficiaryCurrency") {
//       const fx = FX_RATES[value];
//       updated[i].fxRate = fx?.rate || "";
//       updated[i].fxPrefRate = fx?.pref || "";
//       updated[i].convertedAmount = "";
//     }

//     if (field === "amount") {
//       updated[i].convertedAmount =
//         updated[i].fxRate && Number(value) > 0
//           ? (Number(value) * updated[i].fxRate).toFixed(2)
//           : "";
//     }

//     setRows(updated);
//   };

//   /* ============================================================
//      FILE UPLOAD PER BENEFICIARY (REQUIRED)
//   ============================================================ */
//   const handleFileUpload = (index, files) => {
//     const updated = [...rows];
//     let totalSize = 0;

//     for (const file of files) {
//       if (!ALLOWED_TYPES.includes(file.type)) {
//         updated[index].errors.documents = true;
//         setRows(updated);
//         return;
//       }

//       if (file.size > MAX_FILE_SIZE) {
//         updated[index].errors.documents = true;
//         setRows(updated);
//         return;
//       }

//       totalSize += file.size;
//     }

//     if (totalSize > MAX_TOTAL_SIZE) {
//       updated[index].errors.documents = true;
//       setRows(updated);
//       return;
//     }

//     updated[index].documents = Array.from(files);
//     updated[index].errors.documents = false;
//     setRows(updated);
//   };

//   /* ============================================================
//      ADD BENEFICIARY
//   ============================================================ */
//   const handleAddRow = () => {
//     setRows([...rows, { ...EMPTY_BENEFICIARY }]);
//   };

//   /* ============================================================
//      VALIDATION
//   ============================================================ */
//   const validateForm = () => {
//     let valid = true;
//     const updated = [...rows];

//     updated.forEach(r => {
//       r.errors = {};

//       Object.keys(r).forEach(key => {
//         if (key !== "errors" && key !== "documents") {
//           if (r[key] === "" || (key === "amount" && Number(r[key]) <= 0)) {
//             r.errors[key] = true;
//             valid = false;
//           }
//         }
//       });

//       if (!r.documents || r.documents.length === 0) {
//         r.errors.documents = true;
//         valid = false;
//       }
//     });

//     setRows(updated);
//     setGlobalError(valid ? "" : "Please fill all required details");
//     return valid;
//   };

//   /* ============================================================
//      TOTAL
//   ============================================================ */
//   const totalDebit = rows.reduce(
//     (sum, r) => sum + (Number(r.convertedAmount) || 0),
//     0
//   );

//   /* ============================================================
//      SUBMIT
//   ============================================================ */
//   const handleSubmit = (e) => {
//     e.preventDefault();

//     if (!validateForm()) return;

//     if (!remitter.accountNumber || remitter.availableFund === null) {
//       setGlobalError("Please fill all required details");
//       return;
//     }

//     if (totalDebit > remitter.availableFund) {
//       setGlobalError("Please fill all required details");
//       return;
//     }

//     alert("Bulk Remittance Submitted Successfully (Mock)");
//   };

//   /* ============================================================
//      UI
//   ============================================================ */
//   return (
//     <div className="bulk-wrapper">
//       <div className="bulk-card">

//         <h2>International Bulk Remittance</h2>
//         {globalError && <div className="global-error">{globalError}</div>}

//         <form onSubmit={handleSubmit}>

//           <h3>Remitter Details</h3>
//           <div className="row">
//             <input
//               className={`input ${!remitter.accountName && remitter.accountNumber ? "error" : ""}`}
//               placeholder="Customer Account Number"
//               value={remitter.accountNumber}
//               onChange={e => handleAccountLookup(e.target.value)}
//             />
//             <input className="input" value={remitter.accountName} disabled />
//             <input className="input" value={remitter.accountAddress} disabled />
//             <input className="input" value={remitter.currency} disabled />
//             <input
//               className="input"
//               value={remitter.availableFund !== null ? `Available Fund: ${remitter.availableFund}` : ""}
//               disabled
//             />
//           </div>

//           <h3>Beneficiary Transactions</h3>

//           {rows.map((r, i) => (
//             <div key={i} className="row">

//               <input className={`input ${r.errors.name ? "error" : ""}`} placeholder="Beneficiary Name"
//                 value={r.name} onChange={e => handleChange(i, "name", e.target.value)} />

//               <input className={`input ${r.errors.address ? "error" : ""}`} placeholder="Beneficiary Address"
//                 value={r.address} onChange={e => handleChange(i, "address", e.target.value)} />

//               <input className={`input ${r.errors.account ? "error" : ""}`} placeholder="Account / IBAN"
//                 value={r.account} onChange={e => handleChange(i, "account", e.target.value)} />

//               <select className={`input ${r.errors.beneficiaryCurrency ? "error" : ""}`}
//                 value={r.beneficiaryCurrency}
//                 onChange={e => handleChange(i, "beneficiaryCurrency", e.target.value)}>
//                 <option value="">Currency</option>
//                 {CURRENCIES.map(c => <option key={c}>{c}</option>)}
//               </select>

//               <input type="number" className={`input ${r.errors.amount ? "error" : ""}`}
//                 placeholder="Amount"
//                 value={r.amount}
//                 onChange={e => handleChange(i, "amount", e.target.value)} />

//               <input className="input" value={r.fxRate} disabled />
//               <input className="input" value={r.fxPrefRate} disabled />
//               <input className="input" value={r.convertedAmount} disabled />

//               <select className={`input ${r.errors.purpose ? "error" : ""}`}
//                 value={r.purpose}
//                 onChange={e => handleChange(i, "purpose", e.target.value)}>
//                 <option value="">Purpose</option>
//                 {PURPOSES.map(p => <option key={p}>{p}</option>)}
//               </select>

//               <input className={`input ${r.errors.bic ? "error" : ""}`} placeholder="BIC"
//                 value={r.bic} onChange={e => handleChange(i, "bic", e.target.value)} />

//               <input className={`input ${r.errors.swift ? "error" : ""}`} placeholder="SWIFT"
//                 value={r.swift} onChange={e => handleChange(i, "swift", e.target.value)} />

//               <input
//                 type="file"
//                 multiple
//                 className={`input ${r.errors.documents ? "error" : ""}`}
//                 onChange={e => handleFileUpload(i, e.target.files)}
//               />

//               <p className="upload-info">
//                 Allowed: PDF, Word, Excel | Max 1 MB per file | Max 5 MB total
//               </p>

//             </div>
//           ))}

//           <button type="button" onClick={handleAddRow}>
//             + Add Beneficiary
//           </button>

//           <div className="btn-row">
//             <button className="btn-primary">Submit</button>
//           </div>

//         </form>
//       </div>
//     </div>
//   );
// }



// import { useState } from "react";
// import "./BulkPayment.css";

// /* ============================================================
//    MOCK CORE BANKING DATA
// ============================================================ */
// const MOCK_ACCOUNTS = {
//   ACC1001: {
//     name: "John Doe Pvt Ltd",
//     address: "Mumbai, India",
//     currency: "INR",
//     balance: 1500000
//   },
//   ACC2002: {
//     name: "Global Exports LLP",
//     address: "Delhi, India",
//     currency: "INR",
//     balance: 250000
//   }
// };

// /* ============================================================
//    COUNTRY MASTER
// ============================================================ */
// const COUNTRIES = {
//   USA: { code: "US", currency: "USD" },
//   UAE: { code: "AE", currency: "AED" },
//   UK: { code: "GB", currency: "GBP" },
//   China: { code: "CN", currency: "CNY" },
//   Europe: { code: "EU", currency: "EUR" },
//   Japan: { code: "JP", currency: "JPY" }
// };

// /* ============================================================
//    FX RATES
// ============================================================ */
// const FX_RATES = {
//   USD: { rate: 83.25, pref: 82.9 },
//   EUR: { rate: 89.1, pref: 88.5 },
//   AED: { rate: 22.65, pref: 22.4 },
//   CNY: { rate: 11.45, pref: 11.3 },
//   GBP: { rate: 104.2, pref: 103.6 },
//   JPY: { rate: 0.56, pref: 0.54 }
// };

// const PURPOSES = [
//   "Education",
//   "Medical",
//   "Trade",
//   "Investment",
//   "Travel",
//   "Family Maintenance",
//   "Software Services"
// ];

// /* ============================================================
//    FILE CONFIG
// ============================================================ */
// const MAX_FILE_SIZE = 1 * 1024 * 1024;
// const MAX_TOTAL_SIZE = 5 * 1024 * 1024;

// const ALLOWED_TYPES = [
//   "application/pdf",
//   "application/msword",
//   "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
//   "application/vnd.ms-excel",
//   "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
// ];

// /* ============================================================
//    EMPTY BENEFICIARY
// ============================================================ */
// const EMPTY_BENEFICIARY = {
//   name: "",
//   address: "",
//   country: "",
//   countryCode: "",
//   account: "",
//   currency: "",
//   amount: "",
//   fxRate: "",
//   fxPrefRate: "",
//   convertedAmount: "",
//   purpose: "",
//   bic: "",
//   swift: "",
//   documents: [],
//   errors: {}
// };

// /* ============================================================
//    COMPONENT
// ============================================================ */
// export default function BulkPayment() {
//   const [remitter, setRemitter] = useState({
//     accountNumber: "",
//     accountName: "",
//     accountAddress: "",
//     currency: "",
//     userName: "",
//     availableFund: null
//   });

//   const [rows, setRows] = useState([
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY }
//   ]);

//   const [globalError, setGlobalError] = useState("");

//   /* ============================================================
//      ACCOUNT LOOKUP
//   ============================================================ */
//   const handleAccountLookup = (value) => {
//     const acc = MOCK_ACCOUNTS[value];
//     if (!acc) {
//       setRemitter({ ...remitter, accountNumber: value, accountName: "", accountAddress: "", currency: "", availableFund: null });
//       return;
//     }
//     setRemitter({
//       ...remitter,
//       accountNumber: value,
//       accountName: acc.name,
//       accountAddress: acc.address,
//       currency: acc.currency,
//       availableFund: acc.balance
//     });
//   };

//   /* ============================================================
//      FIELD CHANGE
//   ============================================================ */
//   const handleChange = (i, field, value) => {
//     const updated = [...rows];
//     updated[i][field] = value;
//     updated[i].errors[field] = false;

//     if (field === "country") {
//       const c = COUNTRIES[value];
//       updated[i].countryCode = c.code;
//       updated[i].currency = c.currency;
//       const fx = FX_RATES[c.currency];
//       updated[i].fxRate = fx.rate;
//       updated[i].fxPrefRate = fx.pref;
//     }

//     if (field === "amount") {
//       updated[i].convertedAmount =
//         updated[i].fxRate && Number(value) > 0
//           ? (Number(value) * updated[i].fxRate).toFixed(2)
//           : "";
//     }

//     setRows(updated);
//   };

//   /* ============================================================
//      FILE UPLOAD
//   ============================================================ */
//   const handleFileUpload = (i, files) => {
//     const updated = [...rows];
//     let total = 0;

//     for (const f of files) {
//       if (!ALLOWED_TYPES.includes(f.type) || f.size > MAX_FILE_SIZE) {
//         updated[i].errors.documents = true;
//         setRows(updated);
//         return;
//       }
//       total += f.size;
//     }

//     if (total > MAX_TOTAL_SIZE) {
//       updated[i].errors.documents = true;
//       setRows(updated);
//       return;
//     }

//     updated[i].documents = Array.from(files);
//     updated[i].errors.documents = false;
//     setRows(updated);
//   };

//   /* ============================================================
//      ADD BENEFICIARY
//   ============================================================ */
//   const handleAddRow = () => setRows([...rows, { ...EMPTY_BENEFICIARY }]);

//   /* ============================================================
//      VALIDATION
//   ============================================================ */
//   const validateForm = () => {
//     let valid = true;
//     const updated = [...rows];

//     updated.forEach(r => {
//       r.errors = {};
//       Object.keys(r).forEach(k => {
//         if (k !== "errors" && k !== "documents") {
//           if (r[k] === "" || (k === "amount" && Number(r[k]) <= 0)) {
//             r.errors[k] = true;
//             valid = false;
//           }
//         }
//       });
//       if (!r.documents.length) {
//         r.errors.documents = true;
//         valid = false;
//       }
//     });

//     setRows(updated);
//     setGlobalError(valid ? "" : "Please fill all required details");
//     return valid;
//   };

//   const totalDebit = rows.reduce((s, r) => s + (Number(r.convertedAmount) || 0), 0);
//   const amountInWords = `${totalDebit.toFixed(2)} ${remitter.currency} Only`;

//   /* ============================================================
//      SUBMIT
//   ============================================================ */
//   const handleSubmit = (e) => {
//     e.preventDefault();
//     if (!validateForm()) return;
//     if (totalDebit > remitter.availableFund) {
//       setGlobalError("Please fill all required details");
//       return;
//     }
//     alert("Bulk Remittance Submitted Successfully (Mock)");
//   };

//   /* ============================================================
//      UI
//   ============================================================ */
//   return (
//     <div className="bulk-wrapper">
//       <div className="bulk-card">

//         <h2>International Bulk Remittance</h2>
//         {globalError && <div className="global-error">{globalError}</div>}

//         <form onSubmit={handleSubmit}>

//           <h3>Remitter Details</h3>
//           <div className="row">
//             <input className="input" placeholder="Customer Account Number" onChange={e => handleAccountLookup(e.target.value)} />
//             <input className="input" value={remitter.accountName} disabled />
//             <input className="input" value={remitter.accountAddress} disabled />
//             <input className="input" value={remitter.currency} disabled />
//             <input className="input" placeholder="User Name" onChange={e => setRemitter({ ...remitter, userName: e.target.value })} />
//             <input className="input" value={remitter.availableFund ? `Available Fund: ${remitter.availableFund}` : ""} disabled />
//           </div>

//           <h3>Beneficiary Transactions</h3>

//           {rows.map((r, i) => (
//             <div key={i} className="row">
//               <input className={`input ${r.errors.name ? "error" : ""}`} placeholder="Beneficiary Name" onChange={e => handleChange(i, "name", e.target.value)} />
//               <input className={`input ${r.errors.address ? "error" : ""}`} placeholder="Beneficiary Address" onChange={e => handleChange(i, "address", e.target.value)} />
//               <select className={`input ${r.errors.country ? "error" : ""}`} onChange={e => handleChange(i, "country", e.target.value)}>
//                 <option value="">Country</option>
//                 {Object.keys(COUNTRIES).map(c => <option key={c}>{c}</option>)}
//               </select>
//               <input className="input" value={r.countryCode} disabled />
//               <input className={`input ${r.errors.account ? "error" : ""}`} placeholder="Account / IBAN" onChange={e => handleChange(i, "account", e.target.value)} />
//               <input className={`input ${r.errors.amount ? "error" : ""}`} placeholder="Amount" type="number" onChange={e => handleChange(i, "amount", e.target.value)} />
//               <input className="input" value={r.fxRate} disabled />
//               <input className="input" value={r.fxPrefRate} disabled />
//               <input className="input" value={r.convertedAmount} disabled />
//               <select className={`input ${r.errors.purpose ? "error" : ""}`} onChange={e => handleChange(i, "purpose", e.target.value)}>
//                 <option value="">Purpose</option>
//                 {PURPOSES.map(p => <option key={p}>{p}</option>)}
//               </select>
//               <input className={`input ${r.errors.bic ? "error" : ""}`} placeholder="BIC" onChange={e => handleChange(i, "bic", e.target.value)} />
//               <input className={`input ${r.errors.swift ? "error" : ""}`} placeholder="SWIFT" onChange={e => handleChange(i, "swift", e.target.value)} />
//               <input className={`input ${r.errors.documents ? "error" : ""}`} type="file" multiple onChange={e => handleFileUpload(i, e.target.files)} />
//             </div>
//           ))}

//           <button type="button" onClick={handleAddRow}>+ Add Beneficiary</button>

//           <h3>Payment Details</h3>
//           <div className="summary">
//             <p>Date & Time: {new Date().toLocaleString()}</p>
//             <p>Total Amount: {totalDebit.toFixed(2)}</p>
//             <p>Total Amount (Words): {amountInWords}</p>
//             <p>Nature of Payment Valid: Y</p>
//           </div>

//           <div className="btn-row">
//             <button className="btn-primary">Submit</button>
//           </div>

//         </form>
//       </div>
//     </div>
//   );
// }


// import { useState } from "react";
// import "./BulkPayment.css";

// /* ============================================================
//    MOCK CORE BANKING DATA
// ============================================================ */
// const MOCK_ACCOUNTS = {
//   ACC1001: {
//     name: "Amrit",
//     address: "Mumbai, India",
//     currency: "INR",
//     balance: 1500000
//   },
//   ACC2002: {
//     name: "Vikash",
//     address: "Delhi, India",
//     currency: "INR",
//     balance: 250000
//   }
// };

// /* ============================================================
//    COUNTRY MASTER
// ============================================================ */
// const COUNTRIES = {
//   USA: { code: "US", currency: "USD" },
//   UAE: { code: "AE", currency: "AED" },
//   UK: { code: "GB", currency: "GBP" },
//   China: { code: "CN", currency: "CNY" },
//   Europe: { code: "EU", currency: "EUR" },
//   Japan: { code: "JP", currency: "JPY" }
// };

// /* ============================================================
//    FX RATES
// ============================================================ */
// const FX_RATES = {
//   USD: { rate: 83.25, pref: 82.9 },
//   EUR: { rate: 89.1, pref: 88.5 },
//   AED: { rate: 22.65, pref: 22.4 },
//   CNY: { rate: 11.45, pref: 11.3 },
//   GBP: { rate: 104.2, pref: 103.6 },
//   JPY: { rate: 0.56, pref: 0.54 }
// };

// const PURPOSES = [
//   "Education",
//   "Medical",
//   "Trade",
//   "Investment",
//   "Travel",
//   "Family Maintenance",
//   "Software Services"
// ];

// /* ============================================================
//    EMPTY BENEFICIARY
// ============================================================ */
// const EMPTY_BENEFICIARY = {
//   name: "",
//   address: "",
//   country: "",
//   countryCode: "",
//   account: "",
//   currency: "",
//   amount: "",
//   fxRate: "",
//   fxPrefRate: "",
//   convertedAmount: "",
//   purpose: "",
//   bic: "",
//   swift: "",
//   errors: {}
// };

// /* ============================================================
//    COMPONENT
// ============================================================ */
// export default function BulkPayment() {
//   const [remitter, setRemitter] = useState({
//     accountNumber: "",
//     accountName: "",
//     accountAddress: "",
//     currency: "",
//     userName: "",
//     availableFund: null
//   });

//   const [rows, setRows] = useState([
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY }
//   ]);

//   const [attachments, setAttachments] = useState([]);
//   const [globalError, setGlobalError] = useState("");

//   /* ============================================================
//      ACCOUNT LOOKUP
//   ============================================================ */
//   const handleAccountLookup = (value) => {
//     const acc = MOCK_ACCOUNTS[value];
//     if (!acc) {
//       setRemitter({ ...remitter, accountNumber: value, accountName: "", accountAddress: "", currency: "", availableFund: null });
//       return;
//     }
//     setRemitter({
//       ...remitter,
//       accountNumber: value,
//       accountName: acc.name,
//       accountAddress: acc.address,
//       currency: acc.currency,
//       availableFund: acc.balance
//     });
//   };

//   /* ============================================================
//      FIELD CHANGE
//   ============================================================ */
//   const handleChange = (i, field, value) => {
//     const updated = [...rows];
//     updated[i][field] = value;
//     updated[i].errors[field] = false;

//     if (field === "country") {
//       const c = COUNTRIES[value];
//       updated[i].countryCode = c.code;
//       updated[i].currency = c.currency;
//       const fx = FX_RATES[c.currency];
//       updated[i].fxRate = fx.rate;
//       updated[i].fxPrefRate = fx.pref;
//     }

//     if (field === "amount") {
//       updated[i].convertedAmount =
//         updated[i].fxRate && Number(value) > 0
//           ? (Number(value) * updated[i].fxRate).toFixed(2)
//           : "";
//     }

//     setRows(updated);
//   };

//   /* ============================================================
//      ADD / REMOVE BENEFICIARY
//   ============================================================ */
//   const handleAddRow = () => setRows([...rows, { ...EMPTY_BENEFICIARY }]);

//   const handleRemoveRow = (index) => {
//     if (index >= 4) {
//       setRows(rows.filter((_, i) => i !== index));
//     }
//   };

//   /* ============================================================
//      VALIDATION
//   ============================================================ */
//   const validateForm = () => {
//     let valid = true;
//     const updated = [...rows];

//     updated.forEach(r => {
//       r.errors = {};
//       Object.keys(r).forEach(k => {
//         if (k !== "errors") {
//           if (r[k] === "" || (k === "amount" && Number(r[k]) <= 0)) {
//             r.errors[k] = true;
//             valid = false;
//           }
//         }
//       });
//     });

//     if (!attachments.length) valid = false;

//     setRows(updated);
//     setGlobalError(valid ? "" : "Please fill all required details");
//     return valid;
//   };

//   const totalDebit = rows.reduce((s, r) => s + (Number(r.convertedAmount) || 0), 0);
//   const amountInWords = `${totalDebit.toFixed(2)} ${remitter.currency} Only`;

//   /* ============================================================
//      SUBMIT
//   ============================================================ */
//   const handleSubmit = (e) => {
//     e.preventDefault();
//     if (!validateForm()) return;
//     if (totalDebit > remitter.availableFund) {
//       setGlobalError("Please fill all required details");
//       return;
//     }
//     alert("Bulk Remittance Submitted Successfully (Mock)");
//   };

//   /* ============================================================
//      UI
//   ============================================================ */
//   return (
//     <div className="bulk-wrapper">
//       <div className="bulk-card">

//         <h2>International Bulk Remittance</h2>
//         {globalError && <div className="global-error">{globalError}</div>}

//         <form onSubmit={handleSubmit}>

//           <h3>Remitter Details</h3>
//           <div className="row">

//             <div className="field-box">
//               {!remitter.accountNumber && <span className="field-label">Customer Account Number</span>}
//               <input className="input" value={remitter.accountNumber} onChange={e => handleAccountLookup(e.target.value)} />
//             </div>

//             <input className="input" value={remitter.accountName} disabled />
//             <input className="input" value={remitter.accountAddress} disabled />
//             <input className="input" value={remitter.currency} disabled />

//             <div className="field-box">
//               {!remitter.userName && <span className="field-label">User Name</span>}
//               <input className="input" value={remitter.userName} onChange={e => setRemitter({ ...remitter, userName: e.target.value })} />
//             </div>

//             <input className="input" value={remitter.availableFund ? `Available Fund: ${remitter.availableFund}` : ""} disabled />
//           </div>

//           <h3>Beneficiary Transactions</h3>

//           {rows.map((r, i) => (
//             <div key={i} className="row">

//               {["name","address","account","amount","bic","swift"].map(field => (
//                 <div className="field-box" key={field}>
//                   {!r[field] && <span className="field-label">{field.toUpperCase()}</span>}
//                   <input
//                     className={`input ${r.errors[field] ? "error" : ""}`}
//                     type={field === "amount" ? "number" : "text"}
//                     value={r[field]}
//                     onChange={e => handleChange(i, field, e.target.value)}
//                   />
//                 </div>
//               ))}

//               <select className={`input ${r.errors.country ? "error" : ""}`} onChange={e => handleChange(i, "country", e.target.value)}>
//                 <option value="">Country</option>
//                 {Object.keys(COUNTRIES).map(c => <option key={c}>{c}</option>)}
//               </select>

//               <input className="input" value={r.countryCode} disabled />
//               <input className="input" value={r.fxRate} disabled />
//               <input className="input" value={r.fxPrefRate} disabled />
//               <input className="input" value={r.convertedAmount} disabled />

//               <select className={`input ${r.errors.purpose ? "error" : ""}`} onChange={e => handleChange(i, "purpose", e.target.value)}>
//                 <option value="">Purpose</option>
//                 {PURPOSES.map(p => <option key={p}>{p}</option>)}
//               </select>

//               {i >= 4 && (
//                 <button type="button" className="remove-btn" onClick={() => handleRemoveRow(i)}>
//                   Remove
//                 </button>
//               )}
//             </div>
//           ))}

//           <button type="button" onClick={handleAddRow}>+ Add Beneficiary</button>

//           <input type="file" multiple className="input" onChange={e => setAttachments([...e.target.files])} />

//           <h3>Payment Details</h3>
//           <div className="summary">
//             <p>Date & Time: {new Date().toLocaleString()}</p>
//             <p>Total Amount: {totalDebit.toFixed(2)}</p>
//             <p>Total Amount (Words): {amountInWords}</p>
//             <p>Nature of Payment Valid: Y</p>
//           </div>

//           <div className="btn-row">
//             <button className="btn-primary">Submit</button>
//           </div>

//         </form>
//       </div>
//     </div>
//   );
// }


// import { useState } from "react";
// import "./BulkPayment.css";

// /* ============================================================
//    MOCK CORE BANKING DATA
// ============================================================ */
// const MOCK_ACCOUNTS = {
//   ACC1001: {
//     name: "Amrit",
//     address: "Mumbai, India",
//     currency: "INR",
//     balance: 1500000
//   },
//   ACC2002: {
//     name: "Vikash",
//     address: "Delhi, India",
//     currency: "INR",
//     balance: 250000
//   }
// };

// /* ============================================================
//    COUNTRY MASTER
// ============================================================ */
// const COUNTRIES = {
//   USA: { code: "US", currency: "USD" },
//   UAE: { code: "AE", currency: "AED" },
//   UK: { code: "GB", currency: "GBP" },
//   China: { code: "CN", currency: "CNY" },
//   Europe: { code: "EU", currency: "EUR" },
//   Japan: { code: "JP", currency: "JPY" }
// };

// /* ============================================================
//    FX RATES
// ============================================================ */
// const FX_RATES = {
//   USD: { rate: 83.25, pref: 82.9 },
//   EUR: { rate: 89.1, pref: 88.5 },
//   AED: { rate: 22.65, pref: 22.4 },
//   CNY: { rate: 11.45, pref: 11.3 },
//   GBP: { rate: 104.2, pref: 103.6 },
//   JPY: { rate: 0.56, pref: 0.54 }
// };

// const PURPOSES = [
//   "Education",
//   "Medical",
//   "Trade",
//   "Investment",
//   "Travel",
//   "Family Maintenance",
//   "Software Services"
// ];

// /* ============================================================
//    EMPTY BENEFICIARY
// ============================================================ */
// const EMPTY_BENEFICIARY = {
//   name: "",
//   address: "",
//   country: "",
//   countryCode: "",
//   account: "",
//   currency: "",
//   amount: "",
//   fxRate: "",
//   fxPrefRate: "",
//   convertedAmount: "",
//   purpose: "",
//   bic: "",
//   swift: "",
//   errors: {}
// };

// /* ============================================================
//    COMPONENT
// ============================================================ */
// export default function BulkPayment() {
//   const [remitter, setRemitter] = useState({
//     accountNumber: "",
//     accountName: "",
//     accountAddress: "",
//     currency: "",
//     userName: "",
//     availableFund: null
//   });

//   const [rows, setRows] = useState([
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY }
//   ]);

//   const [attachments, setAttachments] = useState([]);
//   const [globalError, setGlobalError] = useState("");

//   /* ============================================================
//      ACCOUNT LOOKUP
//   ============================================================ */
//   const handleAccountLookup = (value) => {
//     const acc = MOCK_ACCOUNTS[value];
//     if (!acc) {
//       setRemitter({ ...remitter, accountNumber: value, accountName: "", accountAddress: "", currency: "", availableFund: null });
//       return;
//     }
//     setRemitter({
//       ...remitter,
//       accountNumber: value,
//       accountName: acc.name,
//       accountAddress: acc.address,
//       currency: acc.currency,
//       availableFund: acc.balance
//     });
//   };

//   /* ============================================================
//      FIELD CHANGE
//   ============================================================ */
//   const handleChange = (i, field, value) => {
//     const updated = [...rows];
//     updated[i][field] = value;
//     updated[i].errors[field] = false;

//     if (field === "country") {
//       const c = COUNTRIES[value];
//       updated[i].countryCode = c.code;
//       updated[i].currency = c.currency;

//       const fx = FX_RATES[c.currency];
//       updated[i].fxRate = fx.rate;
//       updated[i].fxPrefRate = fx.pref;

//       updated[i].amount = "";
//       updated[i].convertedAmount = "";
//     }

//     if (field === "amount") {
//       updated[i].convertedAmount =
//         updated[i].fxRate && Number(value) > 0
//           ? (Number(value) * updated[i].fxRate).toFixed(2)
//           : "";
//     }

//     setRows(updated);
//   };

//   /* ============================================================
//      ADD / REMOVE BENEFICIARY
//   ============================================================ */
//   const handleAddRow = () => setRows([...rows, { ...EMPTY_BENEFICIARY }]);

//   const handleRemoveRow = (index) => {
//     if (index >= 4) {
//       setRows(rows.filter((_, i) => i !== index));
//     }
//   };

//   /* ============================================================
//      VALIDATION
//   ============================================================ */
//   const validateForm = () => {
//     let valid = true;
//     const updated = [...rows];

//     updated.forEach(r => {
//       r.errors = {};
//       Object.keys(r).forEach(k => {
//         if (k !== "errors") {
//           if (r[k] === "" || (k === "amount" && Number(r[k]) <= 0)) {
//             r.errors[k] = true;
//             valid = false;
//           }
//         }
//       });
//     });

//     if (!attachments.length) valid = false;

//     setRows(updated);
//     setGlobalError(valid ? "" : "Please fill all required details");
//     return valid;
//   };

//   const totalDebit = rows.reduce((s, r) => s + (Number(r.convertedAmount) || 0), 0);
//   const amountInWords = `${totalDebit.toFixed(2)} ${remitter.currency} Only`;

//   /* ============================================================
//      SUBMIT
//   ============================================================ */
//   const handleSubmit = (e) => {
//     e.preventDefault();
//     if (!validateForm()) return;
//     if (totalDebit > remitter.availableFund) {
//       setGlobalError("Please fill all required details");
//       return;
//     }
//     alert("Bulk Remittance Submitted Successfully (Mock)");
//   };

//   /* ============================================================
//      UI
//   ============================================================ */
//   return (
//     <div className="bulk-wrapper">
//       <div className="bulk-card">

//         <h2>International Bulk Remittance</h2>
//         {globalError && <div className="global-error">{globalError}</div>}

//         <form onSubmit={handleSubmit}>

//           <h3>Remitter Details</h3>
//           <div className="row">
//             <div className="field-box">
//               {!remitter.accountNumber && <span className="field-label">Customer Account Number</span>}
//               <input className="input" value={remitter.accountNumber} onChange={e => handleAccountLookup(e.target.value)} />
//             </div>

//             <input className="input" value={remitter.accountName} disabled />
//             <input className="input" value={remitter.accountAddress} disabled />
//             <input className="input" value={remitter.currency} disabled />

//             <div className="field-box">
//               {!remitter.userName && <span className="field-label">User Name</span>}
//               <input className="input" value={remitter.userName} onChange={e => setRemitter({ ...remitter, userName: e.target.value })} />
//             </div>

//             <input className="input" value={remitter.availableFund ? `Available Fund: ${remitter.availableFund}` : ""} disabled />
//           </div>

//           <h3>Beneficiary Transactions</h3>

//           {rows.map((r, i) => (
//             <div key={i} className="row">

//               {["name","address","account","amount","bic","swift"].map(field => (
//                 <div className="field-box" key={field}>
//                   {!r[field] && <span className="field-label">{field.toUpperCase()}</span>}
//                   <input
//                     className={`input ${r.errors[field] ? "error" : ""}`}
//                     type={field === "amount" ? "number" : "text"}
//                     value={r[field]}
//                     onChange={e => handleChange(i, field, e.target.value)}
//                   />
//                 </div>
//               ))}

//               {/* COUNTRY */}
//               <div className="field-box">
//                 {!r.country && <span className="field-label">Country</span>}
//                 <select
//                   className={`input ${r.errors.country ? "error" : ""}`}
//                   value={r.country}
//                   onChange={e => handleChange(i, "country", e.target.value)}
//                 >
//                   <option value=""></option>
//                   {Object.keys(COUNTRIES).map(c => (
//                     <option key={c} value={c}>{c}</option>
//                   ))}
//                 </select>
//               </div>

//               {/* AUTO CURRENCY */}
//               <div className="field-box">
//                 {!r.currency && <span className="field-label">Currency</span>}
//                 <input className="input" value={r.currency} disabled />
//               </div>

//               <input className="input" value={r.fxRate} disabled />
//               <input className="input" value={r.fxPrefRate} disabled />
//               <input className="input" value={r.convertedAmount} disabled />

//               <div className="field-box">
//                 {!r.purpose && <span className="field-label">Purpose</span>}
//                 <select
//                   className={`input ${r.errors.purpose ? "error" : ""}`}
//                   value={r.purpose}
//                   onChange={e => handleChange(i, "purpose", e.target.value)}
//                 >
//                   <option value=""></option>
//                   {PURPOSES.map(p => (
//                     <option key={p} value={p}>{p}</option>
//                   ))}
//                 </select>
//               </div>

//               {i >= 4 && (
//                 <button type="button" className="remove-btn" onClick={() => handleRemoveRow(i)}>
//                   Remove
//                 </button>
//               )}
//             </div>
//           ))}

//           <button type="button" onClick={handleAddRow}>+ Add Beneficiary</button>

//           <input type="file" multiple className="input" onChange={e => setAttachments([...e.target.files])} />

//           <h3>Payment Details</h3>
//           <div className="summary">
//             <p>Date & Time: {new Date().toLocaleString()}</p>
//             <p>Total Amount: {totalDebit.toFixed(2)}</p>
//             <p>Total Amount (Words): {amountInWords}</p>
//             <p>Nature of Payment Valid: Y</p>
//           </div>

//           <div className="btn-row">
//             <button className="btn-primary">Submit</button>
//           </div>

//         </form>
//       </div>
//     </div>
//   );
// }




// import { useState } from "react";
// import "./BulkPayment.css";

// /* ============================================================
//    MOCK CORE BANKING DATA
// ============================================================ */
// const MOCK_ACCOUNTS = {
//   ACC1001: {
//     name: "Amrit",
//     address: "Mumbai, India",
//     currency: "INR",
//     balance: 1500000
//   },
//   ACC2002: {
//     name: "Vikash",
//     address: "Delhi, India",
//     currency: "INR",
//     balance: 250000
//   }
// };

// /* ============================================================
//    COUNTRY MASTER
// ============================================================ */
// const COUNTRIES = {
//   USA: { code: "US", currency: "USD" },
//   UAE: { code: "AE", currency: "AED" },
//   UK: { code: "GB", currency: "GBP" },
//   China: { code: "CN", currency: "CNY" },
//   Europe: { code: "EU", currency: "EUR" },
//   Japan: { code: "JP", currency: "JPY" }
// };

// /* ============================================================
//    FX RATES
// ============================================================ */
// const FX_RATES = {
//   USD: { rate: 83.25, pref: 82.9 },
//   EUR: { rate: 89.1, pref: 88.5 },
//   AED: { rate: 22.65, pref: 22.4 },
//   CNY: { rate: 11.45, pref: 11.3 },
//   GBP: { rate: 104.2, pref: 103.6 },
//   JPY: { rate: 0.56, pref: 0.54 }
// };

// const PURPOSES = [
//   "Education",
//   "Medical",
//   "Trade",
//   "Investment",
//   "Travel",
//   "Family Maintenance",
//   "Software Services"
// ];

// /* ============================================================
//    EMPTY BENEFICIARY
// ============================================================ */
// const EMPTY_BENEFICIARY = {
//   name: "",
//   address: "",
//   country: "",
//   countryCode: "",
//   account: "",
//   currency: "",
//   amount: "",
//   fxRate: "",
//   fxPrefRate: "",
//   convertedAmount: "",
//   purpose: "",
//   bic: "",
//   swift: "",
//   errors: {}
// };

// /* ============================================================
//    COMPONENT
// ============================================================ */
// export default function BulkPayment() {
//   const [remitter, setRemitter] = useState({
//     accountNumber: "",
//     accountName: "",
//     accountAddress: "",
//     currency: "",
//     userName: "",
//     availableFund: null
//   });

//   const [rows, setRows] = useState([
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY },
//     { ...EMPTY_BENEFICIARY }
//   ]);

//   const [attachments, setAttachments] = useState([]);
//   const [globalError, setGlobalError] = useState("");

//   /* ============================================================
//      ACCOUNT LOOKUP
//   ============================================================ */
//   const handleAccountLookup = (value) => {
//     const acc = MOCK_ACCOUNTS[value];
//     if (!acc) {
//       setRemitter({ ...remitter, accountNumber: value, accountName: "", accountAddress: "", currency: "", availableFund: null });
//       return;
//     }
//     setRemitter({
//       ...remitter,
//       accountNumber: value,
//       accountName: acc.name,
//       accountAddress: acc.address,
//       currency: acc.currency,
//       availableFund: acc.balance
//     });
//   };

//   /* ============================================================
//      FIELD CHANGE
//   ============================================================ */
//   const handleChange = (i, field, value) => {
//     const updated = [...rows];
//     updated[i][field] = value;
//     updated[i].errors[field] = false;

//     if (field === "country") {
//       const c = COUNTRIES[value];
//       updated[i].countryCode = c.code;
//       updated[i].currency = c.currency;

//       const fx = FX_RATES[c.currency];
//       updated[i].fxRate = fx.rate;
//       updated[i].fxPrefRate = fx.pref;

//       updated[i].amount = "";
//       updated[i].convertedAmount = "";
//     }

//     if (field === "amount") {
//       updated[i].convertedAmount =
//         updated[i].fxRate && Number(value) > 0
//           ? (Number(value) * updated[i].fxRate).toFixed(2)
//           : "";
//     }

//     setRows(updated);
//   };

//   /* ============================================================
//      ADD / REMOVE BENEFICIARY
//   ============================================================ */
//   const handleAddRow = () => setRows([...rows, { ...EMPTY_BENEFICIARY }]);

//   const handleRemoveRow = (index) => {
//     if (index >= 4) {
//       setRows(rows.filter((_, i) => i !== index));
//     }
//   };

//   /* ============================================================
//      VALIDATION
//   ============================================================ */
//   const validateForm = () => {
//     let valid = true;
//     const updated = [...rows];

//     updated.forEach(r => {
//       r.errors = {};
//       Object.keys(r).forEach(k => {
//         if (k !== "errors") {
//           if (r[k] === "" || (k === "amount" && Number(r[k]) <= 0)) {
//             r.errors[k] = true;
//             valid = false;
//           }
//         }
//       });
//     });

//     if (!attachments.length) valid = false;

//     setRows(updated);
//     setGlobalError(valid ? "" : "Please fill all required details");
//     return valid;
//   };

//   const totalDebit = rows.reduce((s, r) => s + (Number(r.convertedAmount) || 0), 0);
//   const amountInWords = `${totalDebit.toFixed(2)} ${remitter.currency} Only`;

//   /* ============================================================
//      SUBMIT
//   ============================================================ */
//   const handleSubmit = (e) => {
//     e.preventDefault();
//     if (!validateForm()) return;
//     if (totalDebit > remitter.availableFund) {
//       setGlobalError("Please fill all required details");
//       return;
//     }
//     alert("Bulk Remittance Submitted Successfully (Mock)");
//   };

//   /* ============================================================
//      UI
//   ============================================================ */
//   return (
//     <div className="bulk-wrapper">
//       <div className="bulk-card">

//         <h2>International Bulk Remittance</h2>
//         {globalError && <div className="global-error">{globalError}</div>}

//         <form onSubmit={handleSubmit}>

//           <h3>Remitter Details</h3>
//           <div className="row">

//             <div className="field-box">
//               {!remitter.accountNumber && <span className="field-label">Customer Account Number</span>}
//               <input className="input" value={remitter.accountNumber} onChange={e => handleAccountLookup(e.target.value)} />
//             </div>

//             <input className="input" value={remitter.accountName} disabled />
//             <input className="input" value={remitter.accountAddress} disabled />
//             <input className="input" value={remitter.currency} disabled />

//             <div className="field-box">
//               {!remitter.userName && <span className="field-label">User Name</span>}
//               <input className="input" value={remitter.userName} onChange={e => setRemitter({ ...remitter, userName: e.target.value })} />
//             </div>

//             <input className="input" value={remitter.availableFund ? `Available Fund: ${remitter.availableFund}` : ""} disabled />
//           </div>

//           <h3>Beneficiary Transactions</h3>

//           {rows.map((r, i) => (
//             <div key={i} className="row">

//               {["name","address","account","amount","bic","swift"].map(field => (
//                 <div className="field-box" key={field}>
//                   {!r[field] && <span className="field-label">{field.toUpperCase()}</span>}
//                   <input
//                     className={`input ${r.errors[field] ? "error" : ""}`}
//                     type={field === "amount" ? "number" : "text"}
//                     value={r[field]}
//                     onChange={e => handleChange(i, field, e.target.value)}
//                   />
//                 </div>
//               ))}

//               {/* COUNTRY */}
//               <div className="field-box">
//                 {!r.country && <span className="field-label">Country</span>}
//                 <select
//                   className={`input ${r.errors.country ? "error" : ""}`}
//                   value={r.country}
//                   onChange={e => handleChange(i, "country", e.target.value)}
//                 >
//                   <option value=""></option>
//                   {Object.keys(COUNTRIES).map(c => (
//                     <option key={c} value={c}>{c}</option>
//                   ))}
//                 </select>
//               </div>

//               {/* COUNTRY CODE (AUTO) */}
//               <div className="field-box">
//                 {!r.countryCode && <span className="field-label">Country Code</span>}
//                 <input className="input" value={r.countryCode} disabled />
//               </div>

//               {/* CURRENCY (AUTO) */}
//               <div className="field-box">
//                 {!r.currency && <span className="field-label">Currency</span>}
//                 <input className="input" value={r.currency} disabled />
//               </div>

//               <input className="input" value={r.fxRate} disabled />
//               <input className="input" value={r.fxPrefRate} disabled />
//               <input className="input" value={r.convertedAmount} disabled />

//               <div className="field-box">
//                 {!r.purpose && <span className="field-label">Purpose</span>}
//                 <select
//                   className={`input ${r.errors.purpose ? "error" : ""}`}
//                   value={r.purpose}
//                   onChange={e => handleChange(i, "purpose", e.target.value)}
//                 >
//                   <option value=""></option>
//                   {PURPOSES.map(p => (
//                     <option key={p} value={p}>{p}</option>
//                   ))}
//                 </select>
//               </div>

//               {i >= 4 && (
//                 <button type="button" className="remove-btn" onClick={() => handleRemoveRow(i)}>
//                   Remove
//                 </button>
//               )}
//             </div>
//           ))}

//           <button type="button" onClick={handleAddRow}>+ Add Beneficiary</button>

//           <input type="file" multiple className="input" onChange={e => setAttachments([...e.target.files])} />

//           <h3>Payment Details</h3>
//           <div className="summary">
//             <p>Date & Time: {new Date().toLocaleString()}</p>
//             <p>Total Amount: {totalDebit.toFixed(2)}</p>
//             <p>Total Amount (Words): {amountInWords}</p>
//             <p>Nature of Payment Valid: Y</p>
//           </div>

//           <div className="btn-row">
//             <button className="btn-primary">Submit</button>
//           </div>

//         </form>
//       </div>
//     </div>
//   );
// }





import { useState } from "react";
import "./BulkPayment.css";

/* ============================================================
   MOCK CORE BANKING DATA
============================================================ */
const MOCK_ACCOUNTS = {
  ACC1001: {
    name: "Amrit",
    address: "Mumbai, India",
    currency: "INR",
    balance: 1500000
  },
  ACC2002: {
    name: "Vikash",
    address: "Delhi, India",
    currency: "INR",
    balance: 250000
  }
};

/* ============================================================
   COUNTRY MASTER
============================================================ */
const COUNTRIES = {
  USA: { code: "US", currency: "USD" },
  UAE: { code: "AE", currency: "AED" },
  UK: { code: "GB", currency: "GBP" },
  China: { code: "CN", currency: "CNY" },
  Europe: { code: "EU", currency: "EUR" },
  Japan: { code: "JP", currency: "JPY" }
};

/* ============================================================
   FX RATES
============================================================ */
const FX_RATES = {
  USD: { rate: 83.25, pref: 82.9 },
  EUR: { rate: 89.1, pref: 88.5 },
  AED: { rate: 22.65, pref: 22.4 },
  CNY: { rate: 11.45, pref: 11.3 },
  GBP: { rate: 104.2, pref: 103.6 },
  JPY: { rate: 0.56, pref: 0.54 }
};

const PURPOSES = [
  "Education",
  "Medical",
  "Trade",
  "Investment",
  "Travel",
  "Family Maintenance",
  "Software Services"
];

/* ============================================================
   EMPTY BENEFICIARY
============================================================ */
const EMPTY_BENEFICIARY = {
  name: "",
  address: "",
  country: "",
  countryCode: "",
  account: "",
  currency: "",
  amount: "",
  fxRate: "",
  fxPrefRate: "",
  convertedAmount: "",
  purpose: "",
  bic: "",
  swift: "",
  errors: {}
};

/* ============================================================
   COMPONENT
============================================================ */
export default function BulkPayment() {
  const [remitter, setRemitter] = useState({
    accountNumber: "",
    accountName: "",
    accountAddress: "",
    currency: "",
    userName: "",
    availableFund: null
  });

  const [rows, setRows] = useState([
    { ...EMPTY_BENEFICIARY },
    { ...EMPTY_BENEFICIARY },
    { ...EMPTY_BENEFICIARY },
    { ...EMPTY_BENEFICIARY }
  ]);

  const [attachments, setAttachments] = useState([]);
  const [globalError, setGlobalError] = useState("");
  const [showDetails, setShowDetails] = useState(false);

  /* ============================================================
     ACCOUNT LOOKUP
  ============================================================ */
  const handleAccountLookup = (value) => {
    const acc = MOCK_ACCOUNTS[value];
    if (!acc) {
      setRemitter({
        ...remitter,
        accountNumber: value,
        accountName: "",
        accountAddress: "",
        currency: "",
        availableFund: null
      });
      return;
    }
    setRemitter({
      ...remitter,
      accountNumber: value,
      accountName: acc.name,
      accountAddress: acc.address,
      currency: acc.currency,
      availableFund: acc.balance
    });
  };

  /* ============================================================
     FIELD CHANGE
  ============================================================ */
  const handleChange = (i, field, value) => {
    const updated = [...rows];
    updated[i][field] = value;
    updated[i].errors[field] = false;

    if (field === "country") {
      const c = COUNTRIES[value];
      updated[i].countryCode = c.code;
      updated[i].currency = c.currency;

      const fx = FX_RATES[c.currency];
      updated[i].fxRate = fx.rate;
      updated[i].fxPrefRate = fx.pref;

      updated[i].amount = "";
      updated[i].convertedAmount = "";
    }

    if (field === "amount") {
      updated[i].convertedAmount =
        updated[i].fxRate && Number(value) > 0
          ? (Number(value) * updated[i].fxRate).toFixed(2)
          : "";
    }

    setRows(updated);
  };

  /* ============================================================
     ADD / REMOVE BENEFICIARY
  ============================================================ */
  const handleAddRow = () => setRows([...rows, { ...EMPTY_BENEFICIARY }]);

  const handleRemoveRow = (index) => {
    if (index >= 4) {
      setRows(rows.filter((_, i) => i !== index));
    }
  };

  /* ============================================================
     VALIDATION
  ============================================================ */
  const validateForm = () => {
    let valid = true;
    const updated = [...rows];

    updated.forEach(r => {
      r.errors = {};
      Object.keys(r).forEach(k => {
        if (k !== "errors") {
          if (r[k] === "" || (k === "amount" && Number(r[k]) <= 0)) {
            r.errors[k] = true;
            valid = false;
          }
        }
      });
    });

    if (!attachments.length) valid = false;

    setRows(updated);
    setGlobalError(valid ? "" : "Please fill all required details");
    return valid;
  };

  const totalDebit = rows.reduce(
    (s, r) => s + (Number(r.convertedAmount) || 0),
    0
  );

  const amountInWords = `${totalDebit.toFixed(2)} ${remitter.currency} Only`;

  /* ============================================================
     COUNTRY SUMMARY (DETAILS)
  ============================================================ */
  const countrySummary = rows.reduce((acc, r) => {
    if (!r.country || !r.convertedAmount) return acc;
    acc[r.country] = (acc[r.country] || 0) + Number(r.convertedAmount);
    return acc;
  }, {});

  /* ============================================================
     SUBMIT
  ============================================================ */
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    if (totalDebit > remitter.availableFund) {
      setGlobalError("Insufficient balance");
      return;
    }

    alert("Bulk Remittance Submitted Successfully (Mock)");
  };

  /* ============================================================
     UI
  ============================================================ */
  return (
    <div className="bulk-wrapper">
      <div className="bulk-card">

        <h2>International Bulk Remittance</h2>
        {globalError && <div className="global-error">{globalError}</div>}

        <form onSubmit={handleSubmit}>

          <h3>Remitter Details</h3>
          <div className="row">
            <input
              className="input"
              placeholder="Customer Account Number"
              value={remitter.accountNumber}
              onChange={e => handleAccountLookup(e.target.value)}
            />
            <input className="input" value={remitter.accountName} disabled />
            <input className="input" value={remitter.accountAddress} disabled />
            <input className="input" value={remitter.currency} disabled />
            <input
              className="input"
              placeholder="User Name"
              value={remitter.userName}
              onChange={e =>
                setRemitter({ ...remitter, userName: e.target.value })
              }
            />
            <input
              className="input"
              value={
                remitter.availableFund
                  ? `Available Fund: ${remitter.availableFund}`
                  : ""
              }
              disabled
            />
          </div>

          <h3>Beneficiary Transactions</h3>

          {rows.map((r, i) => (
            <div key={i} className="row">

              {["name", "address", "account", "amount", "bic", "swift"].map(
                field => (
                  <input
                    key={field}
                    className={`input ${r.errors[field] ? "error" : ""}`}
                    placeholder={field.toUpperCase()}
                    type={field === "amount" ? "number" : "text"}
                    value={r[field]}
                    onChange={e =>
                      handleChange(i, field, e.target.value)
                    }
                  />
                )
              )}

              <select
                className={`input ${r.errors.country ? "error" : ""}`}
                value={r.country}
                onChange={e => handleChange(i, "country", e.target.value)}
              >
                <option value="">Country</option>
                {Object.keys(COUNTRIES).map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>

              <input className="input" value={r.countryCode} disabled />
              <input className="input" value={r.currency} disabled />
              <input className="input" value={r.fxRate} disabled />
              <input className="input" value={r.fxPrefRate} disabled />
              <input className="input" value={r.convertedAmount} disabled />

              <select
                className={`input ${r.errors.purpose ? "error" : ""}`}
                value={r.purpose}
                onChange={e =>
                  handleChange(i, "purpose", e.target.value)
                }
              >
                <option value="">Purpose</option>
                {PURPOSES.map(p => (
                  <option key={p} value={p}>{p}</option>
                ))}
              </select>

              {i >= 4 && (
                <button
                  type="button"
                  className="remove-btn"
                  onClick={() => handleRemoveRow(i)}
                >
                  Remove
                </button>
              )}
            </div>
          ))}

          <button type="button" onClick={handleAddRow}>
            + Add Beneficiary
          </button>

          <input
            type="file"
            multiple
            className="input"
            onChange={e => setAttachments([...e.target.files])}
          />

          {/* DETAILS PANEL */}
          {showDetails && (
            <div className="details-box">
              <h3>Transaction Details</h3>
              <table className="details-table">
                <thead>
                  <tr>
                    <th>Country</th>
                    <th>Currency</th>
                    <th>Amount (INR)</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(countrySummary).map(([c, amt]) => (
                    <tr key={c}>
                      <td>{c}</td>
                      <td>{COUNTRIES[c].currency}</td>
                      <td>{amt.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          <h3>Payment Details</h3>
          <div className="summary">
            <p>Date & Time: {new Date().toLocaleString()}</p>
            <p>Total Amount: {totalDebit.toFixed(2)}</p>
            <p>Total Amount (Words): {amountInWords}</p>
          </div>

          <div className="btn-row">
            <button
              type="button"
              className="btn-secondary"
              onClick={() => setShowDetails(!showDetails)}
            >
              {showDetails ? "Hide Details" : "View Details"}
            </button>
            <button className="btn-primary">Submit</button>
          </div>

        </form>
      </div>
    </div>
  );
}
