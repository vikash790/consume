// import { useNavigate } from "react-router-dom";

// export default function Register() {
//   const navigate = useNavigate();

//   const handleRegister = (e) => {
//     e.preventDefault();

//     // TODO: Add API Logic

//     alert("Registration successful!");
//     navigate("/login");
//   };

//   return (
//     <div style={{ padding: "20px" }}>
//       <h2>Create Account</h2>

//       <form onSubmit={handleRegister}>
//         <input type="text" placeholder="Full Name" required /><br /><br />
//         <input type="email" placeholder="Email" required /><br /><br />
//         <input type="password" placeholder="Password" required /><br /><br />

//         <button type="submit">Register</button>
//       </form>
//     </div>
//   );
// }



// import { useNavigate } from "react-router-dom";

// export default function Register() {
//   const navigate = useNavigate();

//   const handleRegister = (e) => {
//     e.preventDefault();

//     // TODO: Add API Logic for registering user

//     alert("Registration successful!");
//     navigate("/Otp");
//   };

//   return (
//     <div className="login-wrapper">
//       <div className="login-card">
//         <h2>Create Account</h2>
//         <p className="login-sub">Join our secure banking platform</p>

//         <form onSubmit={handleRegister} className="login-form">
          
//           <div className="input-group">
//             <label>Full Name</label>
//             <input type="text" placeholder="John Doe" required />
//           </div>

//           <div className="input-group">
//             <label>Email Address</label>
//             <input type="email" placeholder="example@bank.com" required />
//           </div>

//           <div className="input-group">
//             <label>Password</label>
//             <input type="password" placeholder="Create a strong password" required />
//           </div>

//           <button type="submit" className="btn-primary big login-btn">
//             Register
//           </button>
//         </form>

//         <p className="signup-text">
//           Already have an account? <a href="/login">Login</a>
//         </p>
//       </div>
//     </div>
//   );
// }




import { useNavigate } from "react-router-dom";
import { useState } from "react";

export default function Register() {
  const navigate = useNavigate();

  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  // 🔐 Mock last 5 passwords (In real banking apps → comes from backend)
  const lastFivePasswords = [
    "OldPass@12345",
    "Secure@2023!",
    "Bank@Login#1",
    "Welcome@123!",
    "Test@Password9"
  ];

  const validatePassword = (pwd) => {
    // Length check
    if (pwd.length < 12) {
      return "Password must be at least 12 characters long";
    }

    // Complexity checks
    const upper = /[A-Z]/;
    const lower = /[a-z]/;
    const number = /[0-9]/;
    const symbol = /[^A-Za-z0-9]/;

    if (!upper.test(pwd)) return "Password must include an uppercase letter";
    if (!lower.test(pwd)) return "Password must include a lowercase letter";
    if (!number.test(pwd)) return "Password must include a number";
    if (!symbol.test(pwd)) return "Password must include a symbol";

    // Last 5 password check
    if (lastFivePasswords.includes(pwd)) {
      return "You cannot reuse your last 5 passwords";
    }

    return "";
  };

  const handleRegister = (e) => {
    e.preventDefault();

    const validationError = validatePassword(password);
    if (validationError) {
      setError(validationError);
      return;
    }

    setError("");
    alert("Registration successful!");
    navigate("/Otp");
  };

  return (
    <div className="login-wrapper">
      <div className="login-card">
        <h2>Create Account</h2>
        <p className="login-sub">Join our secure banking platform</p>

        <form onSubmit={handleRegister} className="login-form">

          <div className="input-group">
            <label>Full Name</label>
            <input type="text" placeholder="John Doe" required />
          </div>

          <div className="input-group">
            <label>Email Address</label>
            <input type="email" placeholder="example@bank.com" required />
          </div>

          <div className="input-group">
            <label>Password</label>
            <input
              type="password"
              placeholder="Create a strong password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          {error && <p className="error-text">{error}</p>}

          <button type="submit" className="btn-primary big login-btn">
            Register
          </button>
        </form>

        <p className="signup-text">
          Already have an account? <a href="/login">Login</a>
        </p>
      </div>
    </div>
  );
}
