// // // import { useState } from "react";
// // // import { useNavigate } from "react-router-dom";
// // // import "./Auth.css";

// // // export default function ChangePassword() {
// // //   const navigate = useNavigate();

// // //   const [oldPassword, setOldPassword] = useState("");
// // //   const [newPassword, setNewPassword] = useState("");
// // //   const [confirmPassword, setConfirmPassword] = useState("");
// // //   const [error, setError] = useState("");

// // //   // 🔐 Mock stored password + last 5 (backend responsibility in real apps)
// // //   const currentPassword = "OldPass@12345";
// // //   const lastFivePasswords = [
// // //     "Secure@2023!",
// // //     "Bank@Login#1",
// // //     "Welcome@123!",
// // //     "Test@Password9",
// // //     "OldPass@12345"
// // //   ];

// // //   const validateNewPassword = (pwd) => {
// // //     if (pwd.length < 12) {
// // //       return "Password must be at least 12 characters long";
// // //     }

// // //     if (!/[A-Z]/.test(pwd)) return "Must include an uppercase letter";
// // //     if (!/[a-z]/.test(pwd)) return "Must include a lowercase letter";
// // //     if (!/[0-9]/.test(pwd)) return "Must include a number";
// // //     if (!/[^A-Za-z0-9]/.test(pwd)) return "Must include a symbol";

// // //     if (lastFivePasswords.includes(pwd)) {
// // //       return "You cannot reuse your last 5 passwords";
// // //     }

// // //     if (pwd === oldPassword) {
// // //       return "New password cannot be same as old password";
// // //     }

// // //     return "";
// // //   };

// // //   const handleSubmit = (e) => {
// // //     e.preventDefault();

// // //     if (oldPassword !== currentPassword) {
// // //       setError("Old password is incorrect");
// // //       return;
// // //     }

// // //     const pwdError = validateNewPassword(newPassword);
// // //     if (pwdError) {
// // //       setError(pwdError);
// // //       return;
// // //     }

// // //     if (newPassword !== confirmPassword) {
// // //       setError("New password and confirm password do not match");
// // //       return;
// // //     }

// // //     setError("");
// // //     alert("Password changed successfully");
// // //     navigate("/login"); // or dashboard
// // //   };

// // //   return (
// // //     <div className="login-wrapper">
// // //       <div className="login-card">
// // //         <h2>Change Password</h2>
// // //         <p className="login-sub">
// // //           For security reasons, please update your password
// // //         </p>

// // //         <form onSubmit={handleSubmit} className="login-form">

// // //           <div className="input-group">
// // //             <label>Old Password</label>
// // //             <input
// // //               type="password"
// // //               placeholder="Enter old password"
// // //               value={oldPassword}
// // //               onChange={(e) => setOldPassword(e.target.value)}
// // //               required
// // //             />
// // //           </div>

// // //           <div className="input-group">
// // //             <label>New Password</label>
// // //             <input
// // //               type="password"
// // //               placeholder="Create new password"
// // //               value={newPassword}
// // //               onChange={(e) => setNewPassword(e.target.value)}
// // //               required
// // //             />
// // //           </div>

// // //           <div className="input-group">
// // //             <label>Confirm New Password</label>
// // //             <input
// // //               type="password"
// // //               placeholder="Confirm new password"
// // //               value={confirmPassword}
// // //               onChange={(e) => setConfirmPassword(e.target.value)}
// // //               required
// // //             />
// // //           </div>

// // //           {error && <p className="error-text">{error}</p>}

// // //           <button type="submit" className="btn-primary big login-btn">
// // //             Update Password
// // //           </button>
// // //         </form>
// // //       </div>
// // //     </div>
// // //   );
// // // }


// // import { useState } from "react";
// // import { useNavigate } from "react-router-dom";
// // import "./Auth.css";

// // export default function ChangePassword() {
// //   const navigate = useNavigate();

// //   const [oldPassword, setOldPassword] = useState("");
// //   const [newPassword, setNewPassword] = useState("");
// //   const [confirmPassword, setConfirmPassword] = useState("");
// //   const [error, setError] = useState("");

// //   // ✅ ONLY validate NEW password complexity
// //   const validateNewPassword = (pwd) => {
// //     if (pwd.length < 12) {
// //       return "Password must be at least 12 characters long";
// //     }

// //     if (!/[A-Z]/.test(pwd))
// //       return "Password must include at least one uppercase letter";

// //     if (!/[a-z]/.test(pwd))
// //       return "Password must include at least one lowercase letter";

// //     if (!/[0-9]/.test(pwd))
// //       return "Password must include at least one number";

// //     if (!/[^A-Za-z0-9]/.test(pwd))
// //       return "Password must include at least one symbol";

// //     return "";
// //   };

// //   const handleSubmit = (e) => {
// //     e.preventDefault();

// //     // ❌ No old password validation now

// //     const pwdError = validateNewPassword(newPassword);
// //     if (pwdError) {
// //       setError(pwdError);
// //       return;
// //     }

// //     if (newPassword !== confirmPassword) {
// //       setError("New password and confirm password do not match");
// //       return;
// //     }

// //     setError("");

// //     // 🔐 Mark password as changed (for navbar unlock)
// //     localStorage.setItem("isPasswordChanged", "true");

// //     alert("Password changed successfully");

// //     // Continue flow
// //     navigate("/verify-captcha");
// //   };

// //   return (
// //     <div className="login-wrapper">
// //       <div className="login-card">
// //         <h2>Change Password</h2>
// //         <p className="login-sub">
// //           Please create a strong password to continue
// //         </p>

// //         <form onSubmit={handleSubmit} className="login-form">

// //           {/* OLD PASSWORD — ACCEPT ANY VALUE */}
// //           <div className="input-group">
// //             <label>Old Password</label>
// //             <input
// //               type="password"
// //               placeholder="Enter old password"
// //               value={oldPassword}
// //               onChange={(e) => setOldPassword(e.target.value)}
// //               required
// //             />
// //           </div>

// //           {/* NEW PASSWORD */}
// //           <div className="input-group">
// //             <label>New Password</label>
// //             <input
// //               type="password"
// //               placeholder="Min 12 chars, upper, lower, number, symbol"
// //               value={newPassword}
// //               onChange={(e) => setNewPassword(e.target.value)}
// //               required
// //             />
// //           </div>

// //           {/* CONFIRM PASSWORD */}
// //           <div className="input-group">
// //             <label>Confirm New Password</label>
// //             <input
// //               type="password"
// //               placeholder="Re-enter new password"
// //               value={confirmPassword}
// //               onChange={(e) => setConfirmPassword(e.target.value)}
// //               required
// //             />
// //           </div>

// //           {error && <p className="error-text">{error}</p>}

// //           <button type="submit" className="btn-primary big login-btn">
// //             Update Password
// //           </button>
// //         </form>
// //       </div>
// //     </div>
// //   );
// // }



// import { useState } from "react";
// import { useNavigate } from "react-router-dom";
// import "./Auth.css";

// export default function ChangePassword() {
//   const navigate = useNavigate();

//   const [oldPassword, setOldPassword] = useState("");
//   const [newPassword, setNewPassword] = useState("");
//   const [confirmPassword, setConfirmPassword] = useState("");
//   const [error, setError] = useState("");

//   // ✅ ONLY validate NEW password complexity
//   const validateNewPassword = (pwd) => {
//     if (pwd.length < 12) {
//       return "Password must be at least 12 characters long";
//     }

//     if (!/[A-Z]/.test(pwd))
//       return "Password must include at least one uppercase letter";

//     if (!/[a-z]/.test(pwd))
//       return "Password must include at least one lowercase letter";

//     if (!/[0-9]/.test(pwd))
//       return "Password must include at least one number";

//     if (!/[^A-Za-z0-9]/.test(pwd))
//       return "Password must include at least one symbol";

//     return "";
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();

//     const pwdError = validateNewPassword(newPassword);
//     if (pwdError) {
//       setError(pwdError);
//       return;
//     }

//     if (newPassword !== confirmPassword) {
//       setError("New password and confirm password do not match");
//       return;
//     }

//     setError("");

//     // 🔐 Mark password as changed (for navbar unlock)
//     localStorage.setItem("isPasswordChanged", "true");

//     alert("Password changed successfully");

//     // ✅ Navigate to HOME
//     navigate("/");
//   };

//   return (
//     <div className="login-wrapper">
//       <div className="login-card">
//         <h2>Change Password</h2>
//         <p className="login-sub">
//           Please create a strong password to continue
//         </p>

//         <form onSubmit={handleSubmit} className="login-form">

//           {/* OLD PASSWORD — ACCEPT ANY VALUE */}
//           <div className="input-group">
//             <label>Old Password</label>
//             <input
//               type="password"
//               placeholder="Enter old password"
//               value={oldPassword}
//               onChange={(e) => setOldPassword(e.target.value)}
//               required
//             />
//           </div>

//           {/* NEW PASSWORD */}
//           <div className="input-group">
//             <label>New Password</label>
//             <input
//               type="password"
//               placeholder="Min 12 chars, upper, lower, number, symbol"
//               value={newPassword}
//               onChange={(e) => setNewPassword(e.target.value)}
//               required
//             />
//           </div>

//           {/* CONFIRM PASSWORD */}
//           <div className="input-group">
//             <label>Confirm New Password</label>
//             <input
//               type="password"
//               placeholder="Re-enter new password"
//               value={confirmPassword}
//               onChange={(e) => setConfirmPassword(e.target.value)}
//               required
//             />
//           </div>

//           {error && <p className="error-text">{error}</p>}

//           <button type="submit" className="btn-primary big login-btn">
//             Update Password
//           </button>
//         </form>
//       </div>
//     </div>
//   );
// }




import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Auth.css";

export default function ChangePassword() {
  const navigate = useNavigate();

  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");

  // 👁️ visibility states
  const [showOld, setShowOld] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  // ✅ ONLY validate NEW password complexity
  const validateNewPassword = (pwd) => {
    if (pwd.length < 12) {
      return "Password must be at least 12 characters long";
    }
    if (!/[A-Z]/.test(pwd))
      return "Password must include at least one uppercase letter";
    if (!/[a-z]/.test(pwd))
      return "Password must include at least one lowercase letter";
    if (!/[0-9]/.test(pwd))
      return "Password must include at least one number";
    if (!/[^A-Za-z0-9]/.test(pwd))
      return "Password must include at least one symbol";
    return "";
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const pwdError = validateNewPassword(newPassword);
    if (pwdError) {
      setError(pwdError);
      return;
    }

    if (newPassword !== confirmPassword) {
      setError("New password and confirm password do not match");
      return;
    }

    setError("");

    // 🔐 Unlock navigation
    localStorage.setItem("isPasswordChanged", "true");

    alert("Password changed successfully");
    navigate("/");
  };

  return (
    <div className="login-wrapper">
      <div className="login-card">
        <h2>Change Password</h2>
        <p className="login-sub">
          Please create a strong password to continue
        </p>

        <form onSubmit={handleSubmit} className="login-form">

          {/* OLD PASSWORD */}
          <div className="input-group password-group">
            <label>Old Password</label>
            <input
              type={showOld ? "text" : "password"}
              placeholder="Enter old password"
              value={oldPassword}
              onChange={(e) => setOldPassword(e.target.value)}
              required
            />
            <span
              className="eye-icon"
              onClick={() => setShowOld(!showOld)}
            >
              {showOld ? "🙈" : "👁️"}
            </span>
          </div>

          {/* NEW PASSWORD */}
          <div className="input-group password-group">
            <label>New Password</label>
            <input
              type={showNew ? "text" : "password"}
              placeholder="Min 12 chars, upper, lower, number, symbol"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              required
            />
            <span
              className="eye-icon"
              onClick={() => setShowNew(!showNew)}
            >
              {showNew ? "🙈" : "👁️"}
            </span>
          </div>

          {/* CONFIRM PASSWORD */}
          <div className="input-group password-group">
            <label>Confirm New Password</label>
            <input
              type={showConfirm ? "text" : "password"}
              placeholder="Re-enter new password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
            />
            <span
              className="eye-icon"
              onClick={() => setShowConfirm(!showConfirm)}
            >
              {showConfirm ? "🙈" : "👁️"}
            </span>
          </div>

          {error && <p className="error-text">{error}</p>}

          <button type="submit" className="btn-primary big login-btn">
            Update Password
          </button>
        </form>
      </div>
    </div>
  );
}
