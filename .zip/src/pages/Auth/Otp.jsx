// import { useState, useRef } from "react";
// import { useNavigate } from "react-router-dom";

// export default function Otp() {
//   const navigate = useNavigate();
//   const [otp, setOtp] = useState(["", "", "", "", "", ""]);
//   const inputRefs = useRef([]);

//   const handleChange = (value, index) => {
//     if (!/^[0-9]?$/.test(value)) return; // allow only numbers

//     const newOtp = [...otp];
//     newOtp[index] = value;
//     setOtp(newOtp);

//     // Auto focus next field
//     if (value && index < 5) {
//       inputRefs.current[index + 1].focus();
//     }
//   };

//   const handleKeyDown = (e, index) => {
//     if (e.key === "Backspace" && !otp[index] && index > 0) {
//       inputRefs.current[index - 1].focus();
//     }
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();

//     const finalOtp = otp.join("");

//     if (finalOtp.length !== 6) {
//       alert("Please enter all 6 digits");
//       return;
//     }

//     alert("OTP Verified Successfully!");
//     navigate("/login");
//   };

//   return (
//     <div className="login-wrapper">
//       <div className="login-card">
//         <h2>Verify OTP</h2>
//         <p className="login-sub">Enter the 6-digit code sent to your email</p>

//         <form onSubmit={handleSubmit} className="otp-form">
//           <div className="otp-group">
//             {otp.map((digit, index) => (
//               <input
//                 key={index}
//                 type="text"
//                 maxLength="1"
//                 value={digit}
//                 ref={(el) => (inputRefs.current[index] = el)}
//                 onChange={(e) => handleChange(e.target.value, index)}
//                 onKeyDown={(e) => handleKeyDown(e, index)}
//                 className="otp-input"
//               />
//             ))}
//           </div>

//           <button type="submit" className="btn-primary big login-btn">
//             Verify OTP
//           </button>
//         </form>

//         <p className="signup-text">
//           Didn’t receive the code? <a href="#">Resend OTP</a>
//         </p>
//       </div>
//     </div>
//   );
// }


import { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";

export default function Otp() {
  const navigate = useNavigate();
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const inputRefs = useRef([]);

  const handleChange = (value, index) => {
    if (!/^[0-9]?$/.test(value)) return;

    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    if (value && index < 5) {
      inputRefs.current[index + 1].focus();
    }
  };

  const handleKeyDown = (e, index) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      inputRefs.current[index - 1].focus();
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const finalOtp = otp.join("");

    if (finalOtp.length !== 6) {
      alert("Please enter all 6 digits");
      return;
    }

    alert("OTP Verified Successfully!");

    // ✅ Navigate to Change Password
    navigate("/change-password");
  };

  return (
    <div className="login-wrapper">
      <div className="login-card">
        <h2>Verify OTP</h2>
        <p className="login-sub">Enter the 6-digit code sent to your email</p>

        <form onSubmit={handleSubmit} className="otp-form">
          <div className="otp-group">
            {otp.map((digit, index) => (
              <input
                key={index}
                type="text"
                maxLength="1"
                value={digit}
                ref={(el) => (inputRefs.current[index] = el)}
                onChange={(e) => handleChange(e.target.value, index)}
                onKeyDown={(e) => handleKeyDown(e, index)}
                className="otp-input"
              />
            ))}
          </div>

          <button type="submit" className="btn-primary big login-btn">
            Verify OTP
          </button>
        </form>

        <p className="signup-text">
          Didn’t receive the code? <a href="#">Resend OTP</a>
        </p>
      </div>
    </div>
  );
}
