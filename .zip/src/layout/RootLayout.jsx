import { Outlet } from "react-router-dom";
import UtilityBar from "./UtilityBar";
import Header from "./Header";
import Footer from "./Footer";

export default function RootLayout() {
  return (
    <>
      <UtilityBar />
      <Header />
      <Outlet />
      <Footer />
    </>
  );
}
