// import Container from "../components/Container";

// export default function Footer() {
//   return (
//     <footer className="footer">
//       <Container>
//         <p>© 2025 YourBank. All Rights Reserved.</p>
//       </Container>
//     </footer>
//   );
// }


// import Container from "../components/Container";

// export default function Footer() {
//   return (
//     <footer className="footer">
//       <Container>
//         <div className="footer-inner">
//           <p>© 2025 YourBank. All Rights Reserved.</p>

//           <div className="footer-social">
//             {/* INSTAGRAM */}
//             <a href="#" aria-label="Instagram">
//               <svg
//                 width="26"
//                 height="26"
//                 fill="currentColor"
//                 viewBox="0 0 24 24"
//               >
//                 <path d="M7 2C4.243 2 2 4.243 2 7v10c0 2.757 2.243 5 5 5h10c2.757
//                 0 5-2.243 5-5V7c0-2.757-2.243-5-5-5H7zm10 2c1.654 0 3
//                 1.346 3 3v10c0 1.654-1.346 3-3 3H7c-1.654 0-3-1.346-3-3V7c0-1.654
//                 1.346-3 3-3h10zm-5 3a5 5 0 100 10 5 5 0 000-10zm0 2a3
//                 3 0 110 6 3 3 0 010-6zm4.5-.75a1.25 1.25 0 11-2.5
//                 0 1.25 1.25 0 012.5 0z" />
//               </svg>
//             </a>

//             {/* LINKEDIN */}
//             <a href="https://www.linkedin.com/company/asturaglobal/" aria-label="LinkedIn">
//               <svg
//                 width="26"
//                 height="26"
//                 fill="currentColor"
//                 viewBox="0 0 24 24"
//               >
//                 <path d="M4.98 3.5C4.98 4.88 3.88 6 2.5 6S0 4.88 0
//                 3.5 1.12 1 2.5 1 4.98 2.12 4.98 3.5zM.5 8.5h4V23h-4V8.5zM8.5
//                 8.5h3.8v2h.1c.5-.9 1.7-2.1 3.7-2.1 4 0 4.7 2.6 4.7 6V23h-4v-6.5c0-1.6
//                 0-3.7-2.3-3.7-2.3 0-2.7 1.7-2.7 3.6V23h-4V8.5z" />
//               </svg>
//             </a>
//           </div>
//         </div>
//       </Container>
//     </footer>
//   );
// }


import Container from "../components/Container";

export default function Footer() {
  return (
    <footer className="footer">
      <Container>
        <div className="footer-inner">

          {/* LEFT SIDE */}
          <div className="footer-left">
            <h3 className="footer-logo">YourBank</h3>
            <p className="footer-text">
              © 2025 YourBank. All Rights Reserved.
            </p>
          </div>

          {/* RIGHT SIDE SOCIAL ICONS */}
          <div className="footer-social">
            
            {/* INSTAGRAM */}
            <a href="#" aria-label="Instagram">
              <svg width="26" height="26" fill="currentColor" viewBox="0 0 24 24">
                <path d="M7 2C4.243 2 2 4.243 2 7v10c0 2.757 
                 2.243 5 5 5h10c2.757 0 5-2.243 5-5V7c0-2.757-2.243-5-5-5H7zm10 
                 2c1.654 0 3 1.346 3 3v10c0 1.654-1.346 3-3 
                 3H7c-1.654 0-3-1.346-3-3V7c0-1.654 1.346-3 
                 3-3h10zm-5 3a5 5 0 100 10 5 5 0 000-10zm0 
                 2a3 3 0 110 6 3 3 0 010-6zm4.5-.75a1.25 
                 1.25 0 11-2.5 0 1.25 1.25 0 012.5 0z" />
              </svg>
            </a>

            {/* LINKEDIN */}
            <a href="#" aria-label="LinkedIn">
              <svg width="26" height="26" fill="currentColor" viewBox="0 0 24 24">
                <path d="M4.98 3.5C4.98 4.88 3.88 6 2.5 
                6S0 4.88 0 3.5 1.12 1 2.5 1 4.98 2.12 
                4.98 3.5zM.5 8.5h4V23h-4V8.5zM8.5 
                8.5h3.8v2h.1c.5-.9 1.7-2.1 
                3.7-2.1 4 0 4.7 2.6 4.7 
                6V23h-4v-6.5c0-1.6 0-3.7-2.3-3.7-2.3 
                0-2.7 1.7-2.7 3.6V23h-4V8.5z" />
              </svg>
            </a>

          </div>

        </div>
      </Container>
    </footer>
  );
}
