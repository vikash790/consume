

// // // // import logo from "../assets/logo.jpg";
// // // // import Container from "../components/Container";
// // // // import { Link } from "react-router-dom";


// // // // export default function Header() {
// // // //   return (
// // // //     <header className="header">
// // // //       <Container>
// // // //         <div className="header__inner">
// // // //           {/* <div className="logo-area">
// // // //             <img src={logo} alt="Bank Logo" className="logo" />
// // // //           </div> */}
// // // //                   <div className="logo-area">
// // // //   <Link to="/">
// // // //     <img src={logo} alt="Bank Logo" className="logo" />
// // // //   </Link>
// // // // </div>


// // // //           <nav className="header__nav">
// // // //             <ul>
// // // //               <li><a>About</a></li>
// // // //               <li><a>Borrow</a></li>
// // // //               <li><a>Resources</a></li>
// // // //               <li><a>FxRates</a></li>

// // // //               {/* SCROLL TO PRODUCTS SECTION */}
// // // //               <li><a href="#products">Products</a></li>
// // // //             </ul>
// // // //           </nav>

// // // //           <div className="header__actions">
// // // //             <button className="btn-outline">Login</button>
// // // //             <button className="btn-primary">Register Account</button>
// // // //           </div>
// // // //         </div>
// // // //       </Container>
// // // //     </header>
// // // //   );
// // // // }




// // // import logo from "../assets/logo.jpg";
// // // import Container from "../components/Container";
// // // import { Link } from "react-router-dom";
// // // import { useAuth } from "../context/AuthContext";

// // // export default function Header() {
// // //   const { isLoggedIn, logout } = useAuth();

// // //   return (
// // //     <header className="header">
// // //       <Container>
// // //         <div className="header__inner">

// // //           {/* Logo */}
// // //           <div className="logo-area">
// // //             <Link to="/">
// // //               <img src={logo} alt="Bank Logo" className="logo" />
// // //             </Link>
// // //           </div>

// // //           {/* NAV */}
// // //           <nav className="header__nav">
// // //             <ul>

// // //               {!isLoggedIn && (
// // //                 <>
// // //                   <li><Link to="/">About</Link></li>
// // //                   <li><Link to="/">Borrow</Link></li>
// // //                   <li><Link to="/">Resources</Link></li>
// // //                   <li><Link to="/">FxRates</Link></li>
// // //                   <li><a href="#products">Products</a></li>
// // //                 </>
// // //               )}

// // //               {isLoggedIn && (
// // //                 <>
// // //                   <li><Link to="/statement">Statement</Link></li>
// // //                   <li><Link to="/profile">Profile</Link></li>
// // //                   <li>
// // //                     <button className="btn-outline" onClick={logout}>Logout</button>
// // //                   </li>
// // //                 </>
// // //               )}

// // //             </ul>
// // //           </nav>

// // //           {/* ACTION BUTTONS */}
// // //           <div className="header__actions">
// // //             {!isLoggedIn && (
// // //               <>
// // //                 <Link to="/login">
// // //                   <button className="btn-outline">Login</button>
// // //                 </Link>

// // //                 <Link to="/register">
// // //                   <button className="btn-primary">Register Account</button>
// // //                 </Link>
// // //               </>
// // //             )}
// // //           </div>

// // //         </div>
// // //       </Container>
// // //     </header>
// // //   );
// // // }


// // // import logo from "../assets/logo.jpg";
// // // import Container from "../components/Container";
// // // import { Link, useNavigate } from "react-router-dom";

// // // export default function Header() {
// // //   const navigate = useNavigate();
// // //   const token = localStorage.getItem("token");

// // //   const handleLogout = () => {
// // //     localStorage.removeItem("token");
// // //     navigate("/");
// // //   };

// // //   return (
// // //     <header className="header">
// // //       <Container>
// // //         <div className="header__inner">

// // //           {/* LOGO */}
// // //           <div className="logo-area">
// // //             <Link to="/">
// // //               <img src={logo} alt="Bank Logo" className="logo" />
// // //             </Link>
// // //           </div>

// // //           {/* NAVIGATION */}
// // //           <nav className="header__nav">
// // //             <ul>
// // //               <li><Link to="/">Home</Link></li>
// // //               <li><Link to="/loans">Loans</Link></li>

// // //               {token && (
// // //                 <>
// // //                   <li><Link to="/account">Account</Link></li>
// // //                 </>
// // //               )}
// // //             </ul>
// // //           </nav>

// // //           {/* NAV BUTTONS */}
// // //           <div className="header__actions">

// // //             {/* If NOT logged in → show Login + Register */}
// // //             {!token && (
// // //               <>
// // //                 <Link to="/login">
// // //                   <button className="btn-outline">Login</button>
// // //                 </Link>

// // //                 <Link to="/register">
// // //                   <button className="btn-primary">Register</button>
// // //                 </Link>
// // //               </>
// // //             )}

// // //             {/* If logged in → show Logout */}
// // //             {token && (
// // //               <button className="btn-outline" onClick={handleLogout}>
// // //                 Logout
// // //               </button>
// // //             )}
// // //           </div>

// // //         </div>
// // //       </Container>
// // //     </header>
// // //   );
// // // }


// // import logo from "../assets/logo.jpg";
// // import Container from "../components/Container";
// // import { Link } from "react-router-dom";
// // import { useAuth } from "../context/AuthContext";

// // export default function Header() {
// //   const { isLoggedIn, logout } = useAuth();

// //   return (
// //     <header className="header">
// //       <Container>
// //         <div className="header__inner">

// //           {/* LOGO */}
// //           <div className="logo-area">
// //             <Link to="/">
// //               <img src={logo} alt="Bank Logo" className="logo" />
// //             </Link>
// //           </div>

// //           {/* NAVIGATION */}
// //           <nav className="header__nav">
// //             <ul>
// //               <li><Link to="/">Home</Link></li>
// //               <li><Link to="/loans">Loans</Link></li>

// //               {isLoggedIn && (
// //                 <>
// //                 <li><Link to="/account">Account</Link></li>
// //                   <li><Link to="/profile">Profile</Link></li>
// //                   </>
// //               )}
// //             </ul>
// //           </nav>

// //           {/* ACTION BUTTONS */}
// //           <div className="header__actions">
            
// //             {!isLoggedIn && (
// //               <>
// //                 <Link to="/login">
// //                   <button className="btn-outline">Login</button>
// //                 </Link>

// //                 <Link to="/register">
// //                   <button className="btn-primary">Register</button>
// //                 </Link>
// //               </>
// //             )}

// //             {isLoggedIn && (
// //               <button className="btn-outline" onClick={logout}>
// //                 Logout
// //               </button>
// //             )}

// //           </div>

// //         </div>
// //       </Container>
// //     </header>
// //   );
// // }



// import logo from "../assets/logo.jpg";
// import Container from "../components/Container";
// import { Link, useNavigate } from "react-router-dom";
// import { useAuth } from "../context/AuthContext";

// export default function Header() {
//   const { isLoggedIn, logout } = useAuth();
//   const navigate = useNavigate();

//   const handleLogout = () => {
//     logout();          // update auth state
//     navigate("/");     // redirect to HOME after logout
//   };

//   return (
//     <header className="header">
//       <Container>
//         <div className="header__inner">

//           {/* LOGO */}
//           <div className="logo-area">
//             <Link to="/">
//               <img src={logo} alt="Bank Logo" className="logo" />
//             </Link>
//           </div>

//           {/* NAVIGATION */}
//           <nav className="header__nav">
//             <ul>
//               <li><Link to="/">Home</Link></li>
//               <li><Link to="/loans">Loans</Link></li>

//               {isLoggedIn && (
//                 <>
//                   <li><Link to="/account">Account</Link></li>
//                    <li><Link to="/profile">Profile</Link></li>
//                   <li><Link to="/bulkpayment">BulkPayment</Link></li>
//                 </>
//               )}
//             </ul>
//           </nav>

//           {/* ACTION BUTTONS */}
//           <div className="header__actions">
            
//             {!isLoggedIn && (
//               <>
//                 <Link to="/login">
//                   <button className="btn-outline">Login</button>
//                 </Link>

//                 <Link to="/register">
//                   <button className="btn-primary">Register</button>
//                 </Link>
//               </>
//             )}

//             {isLoggedIn && (
//               <button className="btn-outline" onClick={handleLogout}>
//                 Logout
//               </button>
//             )}

//           </div>

//         </div>
//       </Container>
//     </header>
//   );
// }




// import logo from "../assets/logo.jpg";
// import Container from "../components/Container";
// import { Link, useNavigate } from "react-router-dom";
// import { useAuth } from "../context/AuthContext";

// export default function Header() {
//   const { isLoggedIn, logout } = useAuth();
//   const navigate = useNavigate();

//   const handleLogout = () => {
//     logout();        // update login state
//     navigate("/");   // redirect to Home
//   };

//   return (
//     <header className="header">
//       <Container>
//         <div className="header__inner">

//           {/* LOGO */}
//           <div className="logo-area">
//             <Link to="/">
//               <img src={logo} alt="Bank Logo" className="logo" />
//             </Link>
//           </div>

//           {/* NAVIGATION MENU */}
//           <nav className="header__nav">
//             <ul>
//               <li><Link to="/">Home</Link></li>
//               <li><Link to="/loans">Loans</Link></li>

//               {isLoggedIn && (
//                 <>
//                   <li><Link to="/account">Account</Link></li>
//                   <li><Link to="/profile">Profile</Link></li>
//                   <li><Link to="/bulk-payment">Bulk Payment</Link></li>
//                 </>
//               )}
//             </ul>
//           </nav>

//           {/* BUTTONS (Login / Register / Logout) */}
//           <div className="header__actions">

//             {!isLoggedIn && (
//               <>
//                 <Link to="/login">
//                   <button className="btn-outline">Login</button>
//                 </Link>

//                 <Link to="/register">
//                   <button className="btn-primary">Register</button>
//                 </Link>
//               </>
//             )}

//             {isLoggedIn && (
//               <button className="btn-outline" onClick={handleLogout}>
//                 Logout
//               </button>
//             )}

//           </div>

//         </div>
//       </Container>
//     </header>
//   );
// }



// import logo from "../assets/logo.jpg";
// import Container from "../components/Container";
// import { Link, useNavigate } from "react-router-dom";
// import { useAuth } from "../context/AuthContext";

// export default function Header() {
//   const { isLoggedIn, logout } = useAuth();
//   const navigate = useNavigate();

//   const handleLogout = () => {
//     logout();        // update login state
//     navigate("/");   // redirect to Home
//   };

//   return (
//     <header className="header">
//       <Container>
//         <div className="header__inner">

//           {/* LOGO */}
//           <div className="logo-area">
//             <Link to="/">
//               <img src={logo} alt="Bank Logo" className="logo" />
//             </Link>
//           </div>

//           {/* NAVIGATION MENU */}
//           <nav className="header__nav">
//             <ul>
//               <li><Link to="/">Home</Link></li>
//               <li><Link to="/loans">Loans</Link></li>

//               {isLoggedIn && (
//                 <>
//                   <li><Link to="/account">Account</Link></li>
//                   <li><Link to="/profile">Profile</Link></li>
//                   <li><Link to="/bulk-payment">Payment</Link></li>
//                 </>
//               )}
//             </ul>
//           </nav>

//           {/* BUTTONS (Login / Register / Logout) */}
//           <div className="header__actions">

//             {!isLoggedIn && (
//               <>
//                 <Link to="/login">
//                   <button className="btn-outline">Login</button>
//                 </Link>

//                 <Link to="/register">
//                   <button className="btn-primary">Register</button>
//                 </Link>
//               </>
//             )}

//             {isLoggedIn && (
//               <button className="btn-outline" onClick={handleLogout}>
//                 Logout
//               </button>
//             )}

//           </div>

//         </div>
//       </Container>
//     </header>
//   );
// }




// import logo from "../assets/logo.jpg";
// import Container from "../components/Container";
// import { Link, useNavigate } from "react-router-dom";
// import { useAuth } from "../context/AuthContext";

// export default function Header() {
//   const { isLoggedIn, logout } = useAuth();
//   const navigate = useNavigate();

//   const handleLogout = () => {
//     logout();
//     navigate("/");
//   };

//   return (
//     <header className="header">
//       <Container>
//         <div className="header__inner">

//           {/* LOGO */}
//           <div className="logo-area">
//             <Link to="/">
//               <img src={logo} alt="Bank Logo" className="logo" />
//             </Link>
//           </div>

//           {/* NAVIGATION */}
//           <nav className="header__nav">
//             <ul>

//               <li><Link to="/">Home</Link></li>
//               <li><Link to="/loans">Loans</Link></li>

//               {isLoggedIn && (
//                 <>
//                   <li><Link to="/account">Account</Link></li>
//                   <li><Link to="/profile">Profile</Link></li>

//                   {/* PAYMENT DROPDOWN */}
//                   <li className="dropdown">
//                     <span className="dropdown__toggle">
//                       Payment ▾
//                     </span>

//                     <ul className="dropdown__menu">
//                       <li><Link to="/payments/bulk">Bulk Payment</Link></li>
//                       <li><Link to="/payments/individual">Individual Payment</Link></li>
//                       <li><Link to="/payments/maccs">MACCS Payment</Link></li>
//                       <li><Link to="/payments/salary">Salary Payment</Link></li>
//                       <li><Link to="/payments/payoff">Payoff Payment</Link></li>
//                     </ul>
//                   </li>
//                 </>
//               )}
//             </ul>
//           </nav>

//           {/* ACTION BUTTONS */}
//           <div className="header__actions">

//             {!isLoggedIn && (
//               <>
//                 <Link to="/login">
//                   <button className="btn-outline">Login</button>
//                 </Link>

//                 <Link to="/register">
//                   <button className="btn-primary">Register</button>
//                 </Link>
//               </>
//             )}

//             {isLoggedIn && (
//               <button className="btn-outline" onClick={handleLogout}>
//                 Logout
//               </button>
//             )}

//           </div>

//         </div>
//       </Container>
//     </header>
//   );
// }



// import { useState } from "react";
// import logo from "../assets/logo.jpg";
// import Container from "../components/Container";
// import { NavLink, useNavigate } from "react-router-dom";
// import { useAuth } from "../context/AuthContext";

// export default function Header() {
//   const { isLoggedIn, logout } = useAuth();
//   const navigate = useNavigate();
//   const [openPayment, setOpenPayment] = useState(false);

//   const handleLogout = () => {
//     logout();
//     navigate("/");
//   };

//   return (
//     <header className="header">
//       <Container>
//         <div className="header__inner">

//           {/* LOGO */}
//           <div className="logo-area">
//             <NavLink to="/">
//               <img src={logo} alt="Bank Logo" className="logo" />
//             </NavLink>
//           </div>

//           {/* NAV */}
//           <nav className="header__nav">
//             <ul>
//               <li>
//                 <NavLink to="/" className="nav-link">
//                   Home
//                 </NavLink>
//               </li>

//               <li>
//                 <NavLink to="/loans" className="nav-link">
//                   Loans
//                 </NavLink>
//               </li>

//               {isLoggedIn && (
//                 <>
//                   <li>
//                     <NavLink to="/account" className="nav-link">
//                       Account
//                     </NavLink>
//                   </li>

//                   <li>
//                     <NavLink to="/profile" className="nav-link">
//                       Profile
//                     </NavLink>
//                   </li>

//                   {/* PAYMENT DROPDOWN */}
//                   <li className="dropdown">
//                     <button
//                       className={`dropdown__toggle ${
//                         openPayment ? "active" : ""
//                       }`}
//                       onClick={() => setOpenPayment(!openPayment)}
//                     >
//                       Payment ▾
//                     </button>

//                     {openPayment && (
//                       <ul className="dropdown__menu">
//                         <li>
//                           <NavLink to="/bulk-payment">Bulk Payment</NavLink>
//                         </li>
//                         <li>
//                           <NavLink to="/payments/individual">
//                             Individual Payment
//                           </NavLink>
//                         </li>
//                         <li>
//                           <NavLink to="/payments/maccs">MACCS Payment</NavLink>
//                         </li>
//                         <li>
//                           <NavLink to="/payments/salary">
//                             Salary Payment
//                           </NavLink>
//                         </li>
//                         <li>
//                           <NavLink to="/payments/payoff">
//                             Payoff Payment
//                           </NavLink>
//                         </li>
//                       </ul>
//                     )}
//                   </li>
//                 </>
//               )}
//             </ul>
//           </nav>

//           {/* ACTIONS */}
//           <div className="header__actions">
//             {!isLoggedIn && (
//               <>
//                 <NavLink to="/login">
//                   <button className="btn-outline">Login</button>
//                 </NavLink>
//                 <NavLink to="/register">
//                   <button className="btn-primary">Register</button>
//                 </NavLink>
//               </>
//             )}

//             {isLoggedIn && (
//               <button className="btn-outline" onClick={handleLogout}>
//                 Logout
//               </button>
//             )}
//           </div>

//         </div>
//       </Container>
//     </header>
//   );
// }




import { useState } from "react";
import logo from "../assets/logo.jpg";
import Container from "../components/Container";
import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Header() {
  const { isLoggedIn, logout } = useAuth();
  const navigate = useNavigate();
  const [openPayment, setOpenPayment] = useState(false);

  // 🔐 PASSWORD CHANGE FLAG
  const isPasswordChanged =
    localStorage.getItem("isPasswordChanged") === "true";

  const handleLogout = () => {
    logout();
    localStorage.removeItem("isPasswordChanged"); // reset on logout
    navigate("/");
  };

  return (
    <header className="header">
      <Container>
        <div className="header__inner">

          {/* LOGO */}
          <div className="logo-area">
            <NavLink to="/">
              <img src={logo} alt="Bank Logo" className="logo" />
            </NavLink>
          </div>

          {/* NAV */}
          <nav className="header__nav">
            <ul>
              <li>
                <NavLink to="/" className="nav-link">
                  Home
                </NavLink>
              </li>

              <li>
                <NavLink to="/loans" className="nav-link">
                  Loans
                </NavLink>
              </li>

              {/* 🔐 SHOW ONLY AFTER PASSWORD CHANGE */}
              {isLoggedIn && isPasswordChanged && (
                <>
                  <li>
                    <NavLink to="/account" className="nav-link">
                      Account
                    </NavLink>
                  </li>

                  <li>
                    <NavLink to="/profile" className="nav-link">
                      Profile
                    </NavLink>
                  </li>

                  {/* PAYMENT DROPDOWN */}
                  <li className="dropdown">
                    <button
                      className={`dropdown__toggle ${
                        openPayment ? "active" : ""
                      }`}
                      onClick={() => setOpenPayment(!openPayment)}
                    >
                      Payment ▾
                    </button>

                    {openPayment && (
                      <ul className="dropdown__menu">
                        <li>
                          <NavLink to="/bulk-payment">Bulk Payment</NavLink>
                        </li>
                        <li>
                          <NavLink to="/payments/individual">
                            Individual Payment
                          </NavLink>
                        </li>
                        <li>
                          <NavLink to="/payments/maccs">
                            MACCS Payment
                          </NavLink>
                        </li>
                        <li>
                          <NavLink to="/payments/salary">
                            Salary Payment
                          </NavLink>
                        </li>
                        <li>
                          <NavLink to="/payments/payoff">
                            Payoff Payment
                          </NavLink>
                        </li>
                      </ul>
                    )}
                  </li>
                </>
              )}
            </ul>
          </nav>

          {/* ACTIONS */}
          <div className="header__actions">
            {!isLoggedIn && (
              <>
                <NavLink to="/login">
                  <button className="btn-outline">Login</button>
                </NavLink>
                <NavLink to="/register">
                  <button className="btn-primary">Register</button>
                </NavLink>
              </>
            )}

            {isLoggedIn && (
              <button className="btn-outline" onClick={handleLogout}>
                Logout
              </button>
            )}
          </div>

        </div>
      </Container>
    </header>
  );
}
